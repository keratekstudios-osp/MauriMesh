# MauriMesh Rust Core Engine v2

This kit builds Rust as an optional high-performance MauriMesh mesh brain.

Final architecture:

React Native UI -> TypeScript orchestration/fallback -> Rust Core Engine -> Kotlin native BLE bridge -> Android radio

Hard rule: the app must not depend on 127.0.0.1:4300. Rust strengthens MauriMesh; Rust must never stop standalone offline mode.

Install in Replit Shell:

bash install-maurimesh-rust-core-engine-v2.sh

Then give Replit Agent:

Open docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md and wire the Rust core into real send, receive, ACK, queue, proof, simulation, and debug UI paths.
