# Replit Agent Task: Wire MauriMesh Rust Core Engine v2

## Objective

Wire the Rust core as an optional intelligent mesh engine.

Do not replace working React Native, TypeScript, BLE, offline save, proof ledger, security code, or dashboard code.

## Absolute rules

1. Do not depend on `127.0.0.1:4300`.
2. Rust must be optional.
3. TypeScript fallback must keep the app working if Rust/native bridge is unavailable.
4. Simulation proof must not be labelled physical proof.
5. Existing standalone offline save must keep working.
6. Existing BLE paths must not be deleted.

## Enhancement wiring

### 1. Outgoing message / BLE send path

Search:
- `sendMessage`
- `trySendViaBle`
- `TX_BLE_START`
- `writeCharacteristic`
- `sendViaBle`

Before native send:

```ts
import {
  buildMauriMeshPacketWithRustCore,
  scoreMauriMeshRouteWithRustCore,
} from "@/src/maurimesh/rust-core";

const rustPacket = await buildMauriMeshPacketWithRustCore({
  packetId,
  from,
  to,
  payload,
  route,
});

const routeScore = await scoreMauriMeshRouteWithRustCore(rustPacket, {
  batteryPercent,
  trustScore,
  latencyMs,
  duplicateSeen,
});

if (!routeScore.allowed) {
  throw new Error(routeScore.reason);
}
```

### 2. Incoming packet path

Search:
- `RX_BLE`
- `handleIncomingPacket`
- `onPacketReceived`
- `deliver`
- `onCharacteristicWriteRequest`

After packet parse:

```ts
import { rustCoreBridge } from "@/src/maurimesh/rust-core";

const validation = await rustCoreBridge.validatePacket(parsedPacket);

if (!validation.ok) {
  throw new Error(validation.reason);
}
```

### 3. ACK path

Search:
- `ACK`
- `markBleAck`
- `RX_ACK`
- `DELIVERED`

Wire:

```ts
import { validateMauriMeshAckWithRustCore } from "@/src/maurimesh/rust-core";

const ackResult = await validateMauriMeshAckWithRustCore(packetId, {
  ackId,
  from,
  to,
});

if (!ackResult.valid) {
  throw new Error(ackResult.reason);
}
```

### 4. Store-and-forward queue

Search:
- `queue`
- `storeForward`
- `retry`
- `pendingAck`

Wire:

```ts
import { decideMauriMeshQueueWithRustCore } from "@/src/maurimesh/rust-core";

const queueDecision = await decideMauriMeshQueueWithRustCore({
  sendOk,
  ackReceived,
  retryCount,
  maxRetries: 5,
});
```

### 5. Proof ledger

Search:
- `ProofLedger`
- `recordProof`
- `proofLedgerEngine`
- `packet_sent`
- `ack_received`

Wire:

```ts
import { createMauriMeshProofWithRustCore } from "@/src/maurimesh/rust-core";

const proof = await createMauriMeshProofWithRustCore({
  packetId,
  eventType: "PACKET_SENT",
  source: "BLE_RUNTIME",
  verified: false,
  message: "Packet sent; waiting for physical ACK.",
});
```

### 6. Simulation

Search:
- `simulation`
- `sim`
- `mesh tick`
- `runtime truth`

Wire:

```ts
import { runMauriMeshSimulationTickWithRustCore } from "@/src/maurimesh/rust-core";

const tick = await runMauriMeshSimulationTickWithRustCore();
```

### 7. UI

Add to proof/debug/developer dashboard:

```tsx
import RustCoreStatusPanel from "@/src/maurimesh/rust-core/ui/RustCoreStatusPanel";

<RustCoreStatusPanel />
```

## Required tests

Run:

```bash
bash scripts/test-rust-core-engine-v2.sh
```

If cargo exists:

```bash
cd rust/maurimesh-core
cargo test
cargo run --bin maurimesh-core-cli
```

## Completion report required

Report:

1. Exact files changed.
2. Exact send path wired.
3. Exact receive path wired.
4. Exact ACK path wired.
5. Exact proof path wired.
6. Exact queue path wired.
7. Where RustCoreStatusPanel appears.
8. Whether cargo compiled.
9. Whether fallback works.
10. Remaining blockers.

Completion is not accepted if the app fails when Rust is unavailable.
