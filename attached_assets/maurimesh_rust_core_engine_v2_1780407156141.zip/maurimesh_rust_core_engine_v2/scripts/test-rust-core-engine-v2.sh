#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
RUST="$ROOT/rust/maurimesh-core"

echo ""
echo "============================================================"
echo "TEST MAURIMESH RUST CORE ENGINE V2"
echo "============================================================"
echo ""

required=(
  "$RUST/Cargo.toml"
  "$RUST/src/lib.rs"
  "$RUST/src/types.rs"
  "$RUST/src/hash.rs"
  "$RUST/src/packet.rs"
  "$RUST/src/route.rs"
  "$RUST/src/ack.rs"
  "$RUST/src/queue.rs"
  "$RUST/src/proof.rs"
  "$RUST/src/simulation.rs"
  "$RUST/src/truth.rs"
  "$RUST/src/ffi.rs"
  "$RUST/src/main.rs"
  "$ROOT/src/maurimesh/rust-core/types.ts"
  "$ROOT/src/maurimesh/rust-core/RustFallbackEngine.ts"
  "$ROOT/src/maurimesh/rust-core/RustCoreBridge.ts"
  "$ROOT/src/maurimesh/rust-core/MauriMeshRustEnhancementRuntime.ts"
  "$ROOT/src/maurimesh/rust-core/ui/RustCoreStatusPanel.tsx"
  "$ROOT/src/maurimesh/rust-core/index.ts"
  "$ROOT/docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md"
  "$ROOT/docs/RUST_CORE_ENGINE_V2_ARCHITECTURE.md"
)

for file in "${required[@]}"; do
  if [ ! -f "$file" ]; then
    echo "FAIL missing $file"
    exit 1
  fi
  echo "PASS found $file"
done

echo ""
echo "Cargo test if available"
if command -v cargo >/dev/null 2>&1; then
  cd "$RUST"
  cargo test
  cargo run --bin maurimesh-core-cli
else
  echo "WARN cargo not installed here; source and TS bridge checks passed."
fi

echo ""
echo "ALL RUST CORE V2 CHECKS COMPLETED."
