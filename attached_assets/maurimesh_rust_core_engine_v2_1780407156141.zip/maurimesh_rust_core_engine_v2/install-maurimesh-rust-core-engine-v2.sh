#!/usr/bin/env bash
set -euo pipefail

echo ""
echo "============================================================"
echo "MAURIMESH RUST CORE ENGINE V2 INSTALLER"
echo "Intelligent optional Rust mesh brain + TypeScript fallback"
echo "============================================================"
echo ""

ROOT="$(pwd)"
BACKUP="$ROOT/backup-before-rust-core-engine-v2-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"

cat > "$BACKUP/README.txt" <<'TXT'
Backup marker before installing MauriMesh Rust Core Engine v2.
This installer creates/updates Rust core, TypeScript bridge, docs, and tests.
It does not delete existing app, BLE, API, UI, proof, routing, security, or offline save files.
TXT


mkdir -p "$(dirname "$ROOT/docs/RUST_CORE_ENGINE_V2_ARCHITECTURE.md")"
cat > "$ROOT/docs/RUST_CORE_ENGINE_V2_ARCHITECTURE.md" <<'FILE_EOF'
# MauriMesh Rust Core Engine v2 Architecture

## Purpose

Rust becomes the deterministic, memory-safe, high-performance decision layer for MauriMesh.

Rust enhances:
- packet building
- packet validation
- route scoring
- duplicate/replay blocking
- TTL/hop limit enforcement
- ACK validation
- store-and-forward queue decisions
- simulation ticks
- proof event creation and validation
- runtime truth scoring
- future crypto/PQC layer

## Correct app stack

React Native = UI
TypeScript = orchestration and fallback
Kotlin/Swift = native hardware bridge
Rust = mesh brain
SQLite/MMKV/AsyncStorage = offline memory
Proof Ledger = truth layer
BLE phones = physical proof

## Bad bridge

React Native -> HTTP -> 127.0.0.1:4300

This is not safe for standalone mobile.

## Correct production bridge

React Native -> TypeScript -> Kotlin Native Module -> Rust static library

## Development bridge

React Native -> TypeScript fallback
Replit/API simulation -> Rust CLI optional

## Completion rule

Rust is complete only when the app still works if Rust/native bridge is unavailable.
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/Cargo.toml")"
cat > "$ROOT/rust/maurimesh-core/Cargo.toml" <<'FILE_EOF'
[package]
name = "maurimesh-core"
version = "0.2.0"
edition = "2021"
description = "MauriMesh optional Rust core engine for packet, routing, ACK, queue, proof, simulation, and runtime truth."
license = "UNLICENSED"

[lib]
name = "maurimesh_core"
path = "src/lib.rs"
crate-type = ["rlib", "cdylib", "staticlib"]

[[bin]]
name = "maurimesh-core-cli"
path = "src/main.rs"

[dependencies]
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/types.rs")"
cat > "$ROOT/rust/maurimesh-core/src/types.rs" <<'FILE_EOF'
#[derive(Clone, Debug)]
pub struct MeshPacket {
    pub packet_id: String,
    pub from: String,
    pub to: String,
    pub created_at_ms: u64,
    pub payload: String,
    pub ttl: u8,
    pub hop_count: u8,
    pub route: Vec<String>,
    pub payload_hash: String,
}

#[derive(Clone, Debug)]
pub struct RouteInput {
    pub packet: MeshPacket,
    pub candidate_route: Vec<String>,
    pub battery_percent: u8,
    pub trust_score: u8,
    pub latency_ms: u32,
    pub duplicate_seen: bool,
}

#[derive(Clone, Debug)]
pub struct RouteScore {
    pub allowed: bool,
    pub risk_score: u8,
    pub route_score: u8,
    pub reason: String,
    pub recommended_route: Vec<String>,
}

#[derive(Clone, Debug)]
pub struct AckEvent {
    pub packet_id: String,
    pub ack_id: String,
    pub from: String,
    pub to: String,
    pub created_at_ms: u64,
}

#[derive(Clone, Debug)]
pub struct AckValidation {
    pub valid: bool,
    pub reason: String,
}

#[derive(Clone, Debug)]
pub struct QueueDecision {
    pub should_queue: bool,
    pub should_retry: bool,
    pub should_drop: bool,
    pub reason: String,
}

#[derive(Clone, Debug)]
pub struct ProofEvent {
    pub proof_id: String,
    pub packet_id: String,
    pub event_type: String,
    pub created_at_ms: u64,
    pub source: String,
    pub verified: bool,
    pub message: String,
}

#[derive(Clone, Debug)]
pub struct SimulationNode {
    pub node_id: String,
    pub label: String,
    pub battery_percent: u8,
    pub trust_score: u8,
    pub online: bool,
}

#[derive(Clone, Debug)]
pub struct SimulationTick {
    pub tick_id: String,
    pub node_count: usize,
    pub online_count: usize,
    pub recommended_relay: Option<String>,
    pub message: String,
}

#[derive(Clone, Debug)]
pub struct RuntimeTruthScore {
    pub verified: bool,
    pub score: u8,
    pub reason: String,
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/hash.rs")"
cat > "$ROOT/rust/maurimesh-core/src/hash.rs" <<'FILE_EOF'
pub fn stable_hash(input: &str) -> String {
    let mut hash: u64 = 14695981039346656037;
    for byte in input.as_bytes() {
        hash ^= *byte as u64;
        hash = hash.wrapping_mul(1099511628211);
    }
    format!("{:016x}", hash)
}

pub fn hash_parts(parts: &[&str]) -> String {
    stable_hash(&parts.join("|"))
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/packet.rs")"
cat > "$ROOT/rust/maurimesh-core/src/packet.rs" <<'FILE_EOF'
use crate::hash::hash_parts;
use crate::types::MeshPacket;

pub fn build_packet(mut packet: MeshPacket) -> MeshPacket {
    let route_text = packet.route.join(",");
    packet.payload_hash = hash_parts(&[
        &packet.packet_id,
        &packet.from,
        &packet.to,
        &packet.created_at_ms.to_string(),
        &packet.payload,
        &packet.ttl.to_string(),
        &packet.hop_count.to_string(),
        &route_text,
    ]);
    packet
}

pub fn validate_packet(packet: &MeshPacket) -> Result<(), String> {
    if packet.packet_id.trim().is_empty() { return Err("packet_id is required".into()); }
    if packet.from.trim().is_empty() { return Err("from is required".into()); }
    if packet.to.trim().is_empty() { return Err("to is required".into()); }
    if packet.ttl == 0 { return Err("ttl expired".into()); }
    if packet.hop_count > packet.ttl { return Err("hop_count exceeds ttl".into()); }
    if packet.payload_hash.trim().is_empty() { return Err("payload_hash is required".into()); }

    let expected = build_packet(MeshPacket { payload_hash: String::new(), ..packet.clone() });
    if expected.payload_hash != packet.payload_hash {
        return Err("payload_hash mismatch".into());
    }

    Ok(())
}

pub fn detect_duplicate(packet_id: &str, seen_packet_ids: &[String]) -> bool {
    seen_packet_ids.iter().any(|id| id == packet_id)
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/route.rs")"
cat > "$ROOT/rust/maurimesh-core/src/route.rs" <<'FILE_EOF'
use crate::packet::validate_packet;
use crate::types::{RouteInput, RouteScore};

pub fn score_route(input: RouteInput) -> RouteScore {
    let mut risk: u8 = 0;

    if validate_packet(&input.packet).is_err() { risk = risk.saturating_add(35); }
    if input.packet.ttl == 0 { risk = risk.saturating_add(25); }
    if input.packet.hop_count > input.packet.ttl { risk = risk.saturating_add(25); }
    if input.duplicate_seen { risk = risk.saturating_add(30); }
    if input.battery_percent < 10 { risk = risk.saturating_add(15); }
    if input.trust_score < 45 { risk = risk.saturating_add(25); }
    if input.latency_ms > 8000 { risk = risk.saturating_add(10); }

    if !input.candidate_route.iter().any(|node| node == &input.packet.to) && input.packet.to != "BROADCAST" {
        risk = risk.saturating_add(10);
    }

    let allowed = risk < 45 && !input.duplicate_seen && input.packet.ttl > 0 && input.packet.hop_count <= input.packet.ttl;
    let route_score = 100u8.saturating_sub(risk);

    RouteScore {
        allowed,
        risk_score: risk,
        route_score,
        reason: if allowed { "route allowed by Rust core".into() } else { "route blocked by Rust core safety gate".into() },
        recommended_route: if allowed { input.candidate_route } else { vec![] },
    }
}

pub fn choose_best_route(routes: Vec<RouteInput>) -> Option<RouteScore> {
    routes.into_iter().map(score_route).filter(|score| score.allowed).max_by_key(|score| score.route_score)
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/ack.rs")"
cat > "$ROOT/rust/maurimesh-core/src/ack.rs" <<'FILE_EOF'
use crate::types::{AckEvent, AckValidation};

pub fn validate_ack(expected_packet_id: &str, ack: &AckEvent) -> AckValidation {
    if ack.packet_id != expected_packet_id {
        return AckValidation { valid: false, reason: "ACK packet_id does not match expected packet".into() };
    }

    if ack.ack_id.trim().is_empty() {
        return AckValidation { valid: false, reason: "ACK id is empty".into() };
    }

    if ack.from.trim().is_empty() || ack.to.trim().is_empty() {
        return AckValidation { valid: false, reason: "ACK route identity is incomplete".into() };
    }

    AckValidation { valid: true, reason: "ACK valid".into() }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/queue.rs")"
cat > "$ROOT/rust/maurimesh-core/src/queue.rs" <<'FILE_EOF'
use crate::types::QueueDecision;

pub fn decide_queue(send_ok: bool, ack_received: bool, retry_count: u8, max_retries: u8) -> QueueDecision {
    if send_ok && ack_received {
        return QueueDecision { should_queue: false, should_retry: false, should_drop: false, reason: "packet delivered and ACKed".into() };
    }

    if retry_count >= max_retries {
        return QueueDecision { should_queue: false, should_retry: false, should_drop: true, reason: "max retries reached; drop or require manual review".into() };
    }

    QueueDecision { should_queue: true, should_retry: true, should_drop: false, reason: "packet requires store-and-forward retry".into() }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/proof.rs")"
cat > "$ROOT/rust/maurimesh-core/src/proof.rs" <<'FILE_EOF'
use crate::hash::hash_parts;
use crate::types::ProofEvent;

pub fn create_proof_event(packet_id: &str, event_type: &str, created_at_ms: u64, source: &str, verified: bool, message: &str) -> ProofEvent {
    let proof_id = hash_parts(&[packet_id, event_type, &created_at_ms.to_string(), source, message]);

    ProofEvent {
        proof_id,
        packet_id: packet_id.to_string(),
        event_type: event_type.to_string(),
        created_at_ms,
        source: source.to_string(),
        verified,
        message: message.to_string(),
    }
}

pub fn validate_physical_proof(events: &[ProofEvent]) -> bool {
    let has_sent = events.iter().any(|e| e.event_type == "PACKET_SENT" && e.verified && e.source != "simulation");
    let has_received = events.iter().any(|e| e.event_type == "PACKET_RECEIVED" && e.verified && e.source != "simulation");
    let has_ack = events.iter().any(|e| e.event_type == "ACK_RECEIVED" && e.verified && e.source != "simulation");
    has_sent && has_received && has_ack
}

pub fn validate_simulation_proof(events: &[ProofEvent]) -> bool {
    let has_sent = events.iter().any(|e| e.event_type == "PACKET_SENT");
    let has_received = events.iter().any(|e| e.event_type == "PACKET_RECEIVED");
    let has_ack = events.iter().any(|e| e.event_type == "ACK_RECEIVED");
    has_sent && has_received && has_ack
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/simulation.rs")"
cat > "$ROOT/rust/maurimesh-core/src/simulation.rs" <<'FILE_EOF'
use crate::types::{SimulationNode, SimulationTick};

pub fn run_simulation_tick(tick_id: &str, nodes: Vec<SimulationNode>) -> SimulationTick {
    let node_count = nodes.len();
    let online: Vec<SimulationNode> = nodes.into_iter().filter(|node| node.online).collect();
    let online_count = online.len();

    let recommended_relay = online
        .iter()
        .filter(|node| node.battery_percent >= 20 && node.trust_score >= 60)
        .max_by_key(|node| (node.trust_score as u16) + (node.battery_percent as u16))
        .map(|node| node.node_id.clone());

    SimulationTick {
        tick_id: tick_id.to_string(),
        node_count,
        online_count,
        recommended_relay: recommended_relay.clone(),
        message: match recommended_relay {
            Some(node) => format!("simulation tick complete; recommended relay {}", node),
            None => "simulation tick complete; no safe relay available".into(),
        },
    }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/truth.rs")"
cat > "$ROOT/rust/maurimesh-core/src/truth.rs" <<'FILE_EOF'
use crate::types::RuntimeTruthScore;

pub fn score_runtime_truth(real_native: bool, verified: bool, source_authenticated: bool, physical_evidence: bool) -> RuntimeTruthScore {
    let mut score: u8 = 0;
    if source_authenticated { score = score.saturating_add(20); }
    if real_native { score = score.saturating_add(25); }
    if verified { score = score.saturating_add(20); }
    if physical_evidence { score = score.saturating_add(35); }

    RuntimeTruthScore {
        verified: score >= 80,
        score,
        reason: if score >= 80 { "runtime truth accepted".into() } else { "runtime truth not strong enough for physical proof".into() },
    }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/ffi.rs")"
cat > "$ROOT/rust/maurimesh-core/src/ffi.rs" <<'FILE_EOF'
use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use crate::hash::stable_hash;

#[no_mangle]
pub extern "C" fn maurimesh_core_version() -> *mut c_char {
    CString::new("maurimesh-core-rust-0.2.0").unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn maurimesh_core_hash(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return CString::new("").unwrap().into_raw();
    }

    let c_str = unsafe { CStr::from_ptr(input) };
    let text = c_str.to_string_lossy();
    CString::new(stable_hash(&text)).unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn maurimesh_core_free_string(ptr: *mut c_char) {
    if ptr.is_null() { return; }
    unsafe { let _ = CString::from_raw(ptr); }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/lib.rs")"
cat > "$ROOT/rust/maurimesh-core/src/lib.rs" <<'FILE_EOF'
pub mod types;
pub mod hash;
pub mod packet;
pub mod route;
pub mod ack;
pub mod queue;
pub mod proof;
pub mod simulation;
pub mod truth;
pub mod ffi;

pub use types::*;
pub use packet::*;
pub use route::*;
pub use ack::*;
pub use queue::*;
pub use proof::*;
pub use simulation::*;
pub use truth::*;

#[cfg(test)]
mod tests {
    use super::*;

    fn test_packet() -> MeshPacket {
        build_packet(MeshPacket {
            packet_id: "MM-TEST-001".to_string(),
            from: "PHONE_A".to_string(),
            to: "PHONE_B".to_string(),
            created_at_ms: 1,
            payload: "kia ora".to_string(),
            ttl: 8,
            hop_count: 0,
            route: vec!["PHONE_A".to_string(), "PHONE_B".to_string()],
            payload_hash: String::new(),
        })
    }

    #[test]
    fn packet_hash_is_stable() {
        let p1 = test_packet();
        let p2 = build_packet(MeshPacket { payload_hash: String::new(), ..p1.clone() });
        assert_eq!(p1.payload_hash, p2.payload_hash);
    }

    #[test]
    fn packet_validation_passes() {
        assert!(validate_packet(&test_packet()).is_ok());
    }

    #[test]
    fn route_allows_safe_packet() {
        let packet = test_packet();
        let result = score_route(RouteInput {
            packet,
            candidate_route: vec!["PHONE_A".to_string(), "PHONE_B".to_string()],
            battery_percent: 80,
            trust_score: 90,
            latency_ms: 30,
            duplicate_seen: false,
        });
        assert!(result.allowed);
    }

    #[test]
    fn route_blocks_duplicate() {
        let packet = test_packet();
        let result = score_route(RouteInput {
            packet,
            candidate_route: vec!["PHONE_A".to_string(), "PHONE_B".to_string()],
            battery_percent: 80,
            trust_score: 90,
            latency_ms: 30,
            duplicate_seen: true,
        });
        assert!(!result.allowed);
    }

    #[test]
    fn simulation_proof_is_not_physical_proof() {
        let events = vec![
            create_proof_event("P1", "PACKET_SENT", 1, "simulation", false, "simulation sent"),
            create_proof_event("P1", "PACKET_RECEIVED", 2, "simulation", false, "simulation received"),
            create_proof_event("P1", "ACK_RECEIVED", 3, "simulation", false, "simulation ack"),
        ];

        assert!(validate_simulation_proof(&events));
        assert!(!validate_physical_proof(&events));
    }
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/rust/maurimesh-core/src/main.rs")"
cat > "$ROOT/rust/maurimesh-core/src/main.rs" <<'FILE_EOF'
use maurimesh_core::{
    build_packet, create_proof_event, run_simulation_tick, score_route, validate_ack, AckEvent,
    MeshPacket, RouteInput, SimulationNode,
};

fn main() {
    let packet = build_packet(MeshPacket {
        packet_id: "MM-RUST-SIM-001".to_string(),
        from: "PHONE_A_SIM".to_string(),
        to: "PHONE_B_SIM".to_string(),
        created_at_ms: 1,
        payload: "kia ora from rust core".to_string(),
        ttl: 8,
        hop_count: 0,
        route: vec!["PHONE_A_SIM".to_string(), "PHONE_B_SIM".to_string()],
        payload_hash: String::new(),
    });

    let route = score_route(RouteInput {
        packet: packet.clone(),
        candidate_route: vec!["PHONE_A_SIM".to_string(), "PHONE_B_SIM".to_string()],
        battery_percent: 88,
        trust_score: 91,
        latency_ms: 40,
        duplicate_seen: false,
    });

    let ack = AckEvent {
        packet_id: packet.packet_id.clone(),
        ack_id: "ACK-RUST-SIM-001".to_string(),
        from: "PHONE_B_SIM".to_string(),
        to: "PHONE_A_SIM".to_string(),
        created_at_ms: 2,
    };

    let ack_result = validate_ack(&packet.packet_id, &ack);
    let proof = create_proof_event(&packet.packet_id, "PACKET_SENT", 3, "rust-core-cli", false, "simulation proof event from Rust core");

    let tick = run_simulation_tick(
        "tick-001",
        vec![
            SimulationNode { node_id: "PHONE_A_SIM".to_string(), label: "Sender".to_string(), battery_percent: 88, trust_score: 91, online: true },
            SimulationNode { node_id: "PHONE_B_SIM".to_string(), label: "Receiver".to_string(), battery_percent: 76, trust_score: 94, online: true },
        ],
    );

    println!("MAURIMESH_RUST_CORE_OK");
    println!("packet_id={}", packet.packet_id);
    println!("payload_hash={}", packet.payload_hash);
    println!("route_allowed={}", route.allowed);
    println!("route_score={}", route.route_score);
    println!("ack_valid={}", ack_result.valid);
    println!("proof_id={}", proof.proof_id);
    println!("recommended_relay={}", tick.recommended_relay.unwrap_or_else(|| "none".to_string()));
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/types.ts")"
cat > "$ROOT/src/maurimesh/rust-core/types.ts" <<'FILE_EOF'
export type RustCoreMode = "native-library" | "rust-cli" | "typescript-fallback" | "unavailable";

export interface RustMeshPacket {
  packetId: string;
  from: string;
  to: string;
  createdAtMs: number;
  payload: string;
  ttl: number;
  hopCount: number;
  route: string[];
  payloadHash?: string;
}

export interface RustRouteInput {
  packet: RustMeshPacket;
  candidateRoute: string[];
  batteryPercent: number;
  trustScore: number;
  latencyMs: number;
  duplicateSeen: boolean;
}

export interface RustRouteScore {
  allowed: boolean;
  riskScore: number;
  routeScore: number;
  reason: string;
  recommendedRoute: string[];
  engine: RustCoreMode;
}

export interface RustAckEvent {
  packetId: string;
  ackId: string;
  from: string;
  to: string;
  createdAtMs: number;
}

export interface RustAckValidation {
  valid: boolean;
  reason: string;
  engine: RustCoreMode;
}

export interface RustQueueDecision {
  shouldQueue: boolean;
  shouldRetry: boolean;
  shouldDrop: boolean;
  reason: string;
  engine: RustCoreMode;
}

export interface RustProofEvent {
  proofId: string;
  packetId: string;
  eventType: string;
  createdAtMs: number;
  source: string;
  verified: boolean;
  message: string;
}

export interface RustSimulationNode {
  nodeId: string;
  label: string;
  batteryPercent: number;
  trustScore: number;
  online: boolean;
}

export interface RustSimulationTick {
  tickId: string;
  nodeCount: number;
  onlineCount: number;
  recommendedRelay?: string;
  message: string;
  engine: RustCoreMode;
}

export interface RustRuntimeTruthScore {
  verified: boolean;
  score: number;
  reason: string;
  engine: RustCoreMode;
}

export interface RustCoreStatus {
  available: boolean;
  mode: RustCoreMode;
  version: string;
  reason: string;
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/RustFallbackEngine.ts")"
cat > "$ROOT/src/maurimesh/rust-core/RustFallbackEngine.ts" <<'FILE_EOF'
import type {
  RustAckEvent,
  RustAckValidation,
  RustMeshPacket,
  RustProofEvent,
  RustQueueDecision,
  RustRouteInput,
  RustRouteScore,
  RustRuntimeTruthScore,
  RustSimulationNode,
  RustSimulationTick,
} from "./types";

function stableHash(input: string): string {
  let hash = BigInt("14695981039346656037");
  const prime = BigInt("1099511628211");
  const mask = BigInt("0xffffffffffffffff");

  for (let i = 0; i < input.length; i += 1) {
    hash ^= BigInt(input.charCodeAt(i));
    hash = (hash * prime) & mask;
  }

  return hash.toString(16).padStart(16, "0");
}

export class RustFallbackEngine {
  buildPacket(packet: RustMeshPacket): RustMeshPacket {
    const payloadHash = stableHash([
      packet.packetId,
      packet.from,
      packet.to,
      String(packet.createdAtMs),
      packet.payload,
      String(packet.ttl),
      String(packet.hopCount),
      packet.route.join(","),
    ].join("|"));

    return { ...packet, payloadHash };
  }

  validatePacket(packet: RustMeshPacket): { ok: boolean; reason: string } {
    if (!packet.packetId) return { ok: false, reason: "packetId is required." };
    if (!packet.from) return { ok: false, reason: "from is required." };
    if (!packet.to) return { ok: false, reason: "to is required." };
    if (packet.ttl <= 0) return { ok: false, reason: "ttl expired." };
    if (packet.hopCount > packet.ttl) return { ok: false, reason: "hopCount exceeds ttl." };
    if (!packet.payloadHash) return { ok: false, reason: "payloadHash is required." };

    const rebuilt = this.buildPacket({ ...packet, payloadHash: undefined });
    if (rebuilt.payloadHash !== packet.payloadHash) return { ok: false, reason: "payloadHash mismatch." };

    return { ok: true, reason: "packet valid." };
  }

  scoreRoute(input: RustRouteInput): RustRouteScore {
    let riskScore = 0;
    const validation = this.validatePacket(input.packet);

    if (!validation.ok) riskScore += 35;
    if (input.packet.ttl <= 0) riskScore += 25;
    if (input.packet.hopCount > input.packet.ttl) riskScore += 25;
    if (input.duplicateSeen) riskScore += 30;
    if (input.batteryPercent < 10) riskScore += 15;
    if (input.trustScore < 45) riskScore += 25;
    if (input.latencyMs > 8000) riskScore += 10;
    if (!input.candidateRoute.includes(input.packet.to) && input.packet.to !== "BROADCAST") riskScore += 10;

    const allowed = riskScore < 45 && !input.duplicateSeen && input.packet.ttl > 0 && input.packet.hopCount <= input.packet.ttl;

    return {
      allowed,
      riskScore,
      routeScore: Math.max(0, 100 - riskScore),
      reason: allowed ? "route allowed by TypeScript Rust fallback" : `route blocked by TypeScript Rust fallback: ${validation.reason}`,
      recommendedRoute: allowed ? input.candidateRoute : [],
      engine: "typescript-fallback",
    };
  }

  validateAck(expectedPacketId: string, ack: RustAckEvent): RustAckValidation {
    if (ack.packetId !== expectedPacketId) return { valid: false, reason: "ACK packetId does not match expected packet.", engine: "typescript-fallback" };
    if (!ack.ackId || !ack.from || !ack.to) return { valid: false, reason: "ACK is incomplete.", engine: "typescript-fallback" };
    return { valid: true, reason: "ACK valid.", engine: "typescript-fallback" };
  }

  decideQueue(input: { sendOk: boolean; ackReceived: boolean; retryCount: number; maxRetries: number }): RustQueueDecision {
    if (input.sendOk && input.ackReceived) {
      return { shouldQueue: false, shouldRetry: false, shouldDrop: false, reason: "packet delivered and ACKed.", engine: "typescript-fallback" };
    }

    if (input.retryCount >= input.maxRetries) {
      return { shouldQueue: false, shouldRetry: false, shouldDrop: true, reason: "max retries reached; drop or manual review required.", engine: "typescript-fallback" };
    }

    return { shouldQueue: true, shouldRetry: true, shouldDrop: false, reason: "packet requires store-and-forward retry.", engine: "typescript-fallback" };
  }

  createProofEvent(input: Omit<RustProofEvent, "proofId">): RustProofEvent {
    const proofId = stableHash([input.packetId, input.eventType, String(input.createdAtMs), input.source, input.message].join("|"));
    return { ...input, proofId };
  }

  runSimulationTick(tickId: string, nodes: RustSimulationNode[]): RustSimulationTick {
    const online = nodes.filter((node) => node.online);
    const relay = online
      .filter((node) => node.batteryPercent >= 20 && node.trustScore >= 60)
      .sort((a, b) => (b.batteryPercent + b.trustScore) - (a.batteryPercent + a.trustScore))[0];

    return {
      tickId,
      nodeCount: nodes.length,
      onlineCount: online.length,
      recommendedRelay: relay?.nodeId,
      message: relay ? `simulation tick complete; recommended relay ${relay.nodeId}` : "simulation tick complete; no safe relay available",
      engine: "typescript-fallback",
    };
  }

  scoreRuntimeTruth(input: { realNative: boolean; verified: boolean; sourceAuthenticated: boolean; physicalEvidence: boolean }): RustRuntimeTruthScore {
    let score = 0;
    if (input.sourceAuthenticated) score += 20;
    if (input.realNative) score += 25;
    if (input.verified) score += 20;
    if (input.physicalEvidence) score += 35;

    return {
      verified: score >= 80,
      score,
      reason: score >= 80 ? "runtime truth accepted" : "runtime truth not strong enough for physical proof",
      engine: "typescript-fallback",
    };
  }
}

export const rustFallbackEngine = new RustFallbackEngine();
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/RustCoreBridge.ts")"
cat > "$ROOT/src/maurimesh/rust-core/RustCoreBridge.ts" <<'FILE_EOF'
import type {
  RustAckEvent,
  RustAckValidation,
  RustCoreStatus,
  RustMeshPacket,
  RustProofEvent,
  RustQueueDecision,
  RustRouteInput,
  RustRouteScore,
  RustRuntimeTruthScore,
  RustSimulationNode,
  RustSimulationTick,
} from "./types";
import { rustFallbackEngine } from "./RustFallbackEngine";

export class RustCoreBridge {
  async status(): Promise<RustCoreStatus> {
    return {
      available: true,
      mode: "typescript-fallback",
      version: "maurimesh-core-v2-fallback",
      reason: "Rust core source is installed. TypeScript fallback is active until Kotlin/JSI native Rust bridge is wired.",
    };
  }

  async buildPacket(packet: RustMeshPacket): Promise<RustMeshPacket> {
    return rustFallbackEngine.buildPacket(packet);
  }

  async validatePacket(packet: RustMeshPacket): Promise<{ ok: boolean; reason: string }> {
    return rustFallbackEngine.validatePacket(packet);
  }

  async scoreRoute(input: RustRouteInput): Promise<RustRouteScore> {
    return rustFallbackEngine.scoreRoute(input);
  }

  async validateAck(expectedPacketId: string, ack: RustAckEvent): Promise<RustAckValidation> {
    return rustFallbackEngine.validateAck(expectedPacketId, ack);
  }

  async decideQueue(input: { sendOk: boolean; ackReceived: boolean; retryCount: number; maxRetries: number }): Promise<RustQueueDecision> {
    return rustFallbackEngine.decideQueue(input);
  }

  async createProofEvent(input: Omit<RustProofEvent, "proofId">): Promise<RustProofEvent> {
    return rustFallbackEngine.createProofEvent(input);
  }

  async runSimulationTick(tickId: string, nodes: RustSimulationNode[]): Promise<RustSimulationTick> {
    return rustFallbackEngine.runSimulationTick(tickId, nodes);
  }

  async scoreRuntimeTruth(input: { realNative: boolean; verified: boolean; sourceAuthenticated: boolean; physicalEvidence: boolean }): Promise<RustRuntimeTruthScore> {
    return rustFallbackEngine.scoreRuntimeTruth(input);
  }
}

export const rustCoreBridge = new RustCoreBridge();
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/MauriMeshRustEnhancementRuntime.ts")"
cat > "$ROOT/src/maurimesh/rust-core/MauriMeshRustEnhancementRuntime.ts" <<'FILE_EOF'
import { rustCoreBridge } from "./RustCoreBridge";
import type { RustMeshPacket, RustProofEvent } from "./types";

export async function buildMauriMeshPacketWithRustCore(input: {
  packetId: string;
  from: string;
  to: string;
  payload: string;
  route?: string[];
  ttl?: number;
  hopCount?: number;
}): Promise<RustMeshPacket> {
  return rustCoreBridge.buildPacket({
    packetId: input.packetId,
    from: input.from,
    to: input.to,
    createdAtMs: Date.now(),
    payload: input.payload,
    ttl: input.ttl ?? 8,
    hopCount: input.hopCount ?? 0,
    route: input.route ?? [input.from, input.to],
  });
}

export async function scoreMauriMeshRouteWithRustCore(packet: RustMeshPacket, input: {
  batteryPercent?: number;
  trustScore?: number;
  latencyMs?: number;
  duplicateSeen?: boolean;
} = {}) {
  return rustCoreBridge.scoreRoute({
    packet,
    candidateRoute: packet.route,
    batteryPercent: input.batteryPercent ?? 100,
    trustScore: input.trustScore ?? 75,
    latencyMs: input.latencyMs ?? 0,
    duplicateSeen: input.duplicateSeen ?? false,
  });
}

export async function validateMauriMeshAckWithRustCore(packetId: string, ack: { ackId: string; from: string; to: string }) {
  return rustCoreBridge.validateAck(packetId, {
    packetId,
    ackId: ack.ackId,
    from: ack.from,
    to: ack.to,
    createdAtMs: Date.now(),
  });
}

export async function decideMauriMeshQueueWithRustCore(input: {
  sendOk: boolean;
  ackReceived: boolean;
  retryCount: number;
  maxRetries?: number;
}) {
  return rustCoreBridge.decideQueue({
    sendOk: input.sendOk,
    ackReceived: input.ackReceived,
    retryCount: input.retryCount,
    maxRetries: input.maxRetries ?? 5,
  });
}

export async function createMauriMeshProofWithRustCore(input: {
  packetId: string;
  eventType: string;
  source: string;
  verified: boolean;
  message: string;
}): Promise<RustProofEvent> {
  return rustCoreBridge.createProofEvent({
    packetId: input.packetId,
    eventType: input.eventType,
    createdAtMs: Date.now(),
    source: input.source,
    verified: input.verified,
    message: input.message,
  });
}

export async function runMauriMeshSimulationTickWithRustCore() {
  return rustCoreBridge.runSimulationTick(`tick-${Date.now()}`, [
    { nodeId: "PHONE_A_SIM", label: "Sender", batteryPercent: 88, trustScore: 91, online: true },
    { nodeId: "PHONE_B_SIM", label: "Receiver", batteryPercent: 76, trustScore: 94, online: true },
    { nodeId: "PHONE_C_SIM", label: "Relay", batteryPercent: 92, trustScore: 86, online: true },
  ]);
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/ui/RustCoreStatusPanel.tsx")"
cat > "$ROOT/src/maurimesh/rust-core/ui/RustCoreStatusPanel.tsx" <<'FILE_EOF'
import React, { useEffect, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import {
  buildMauriMeshPacketWithRustCore,
  createMauriMeshProofWithRustCore,
  decideMauriMeshQueueWithRustCore,
  runMauriMeshSimulationTickWithRustCore,
  rustCoreBridge,
  scoreMauriMeshRouteWithRustCore,
  validateMauriMeshAckWithRustCore,
} from "../index";

const card = {
  backgroundColor: "#0F172A",
  borderRadius: 18,
  borderWidth: 1,
  borderColor: "rgba(0,208,132,0.35)",
  padding: 16,
  marginBottom: 12,
} as const;

const title = { color: "#FFFFFF", fontSize: 20, fontWeight: "800" as const, marginBottom: 8 };
const text = { color: "#CFFAFE", fontSize: 13, lineHeight: 19 };
const button = { backgroundColor: "#00D084", padding: 12, borderRadius: 14, marginTop: 10 };
const buttonText = { color: "#03140D", fontWeight: "800" as const, textAlign: "center" as const };

export default function RustCoreStatusPanel() {
  const [status, setStatus] = useState<any>(null);
  const [result, setResult] = useState<any>(null);

  async function refresh() {
    setStatus(await rustCoreBridge.status());
  }

  async function runFullFlow() {
    const packet = await buildMauriMeshPacketWithRustCore({
      packetId: `MM-RUST-UI-${Date.now()}`,
      from: "PHONE_A",
      to: "PHONE_B",
      payload: "kia ora from MauriMesh Rust Core v2",
    });

    const packetValidation = await rustCoreBridge.validatePacket(packet);
    const route = await scoreMauriMeshRouteWithRustCore(packet, {
      batteryPercent: 88,
      trustScore: 91,
      latencyMs: 40,
      duplicateSeen: false,
    });

    const ack = await validateMauriMeshAckWithRustCore(packet.packetId, {
      ackId: `ACK-${packet.packetId}`,
      from: "PHONE_B",
      to: "PHONE_A",
    });

    const queue = await decideMauriMeshQueueWithRustCore({
      sendOk: route.allowed,
      ackReceived: ack.valid,
      retryCount: 0,
    });

    const proof = await createMauriMeshProofWithRustCore({
      packetId: packet.packetId,
      eventType: "RUST_CORE_SIMULATION",
      source: "RustCoreStatusPanel",
      verified: false,
      message: "Rust core enhanced packet, route, ACK, queue, and proof logic. Simulation only, not physical BLE proof.",
    });

    const simulation = await runMauriMeshSimulationTickWithRustCore();

    const truth = await rustCoreBridge.scoreRuntimeTruth({
      realNative: false,
      verified: true,
      sourceAuthenticated: true,
      physicalEvidence: false,
    });

    setResult({ packet, packetValidation, route, ack, queue, proof, simulation, truth });
  }

  useEffect(() => { refresh(); }, []);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#020617" }} contentContainerStyle={{ padding: 16 }}>
      <View style={card}>
        <Text style={title}>MauriMesh Rust Core v2</Text>
        <Text style={text}>Available: {String(status?.available ?? false)}</Text>
        <Text style={text}>Mode: {status?.mode ?? "unknown"}</Text>
        <Text style={text}>Version: {status?.version ?? "unknown"}</Text>
        <Text style={text}>Reason: {status?.reason ?? "not checked"}</Text>

        <TouchableOpacity style={button} onPress={refresh}>
          <Text style={buttonText}>Refresh Rust Core Status</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={runFullFlow}>
          <Text style={buttonText}>Run Full Rust Core Flow</Text>
        </TouchableOpacity>
      </View>

      {result ? (
        <View style={card}>
          <Text style={title}>Rust Core Result</Text>
          <Text style={text}>{JSON.stringify(result, null, 2)}</Text>
        </View>
      ) : null}
    </ScrollView>
  );
}
FILE_EOF


mkdir -p "$(dirname "$ROOT/src/maurimesh/rust-core/index.ts")"
cat > "$ROOT/src/maurimesh/rust-core/index.ts" <<'FILE_EOF'
export * from "./types";
export * from "./RustFallbackEngine";
export * from "./RustCoreBridge";
export * from "./MauriMeshRustEnhancementRuntime";
FILE_EOF


mkdir -p "$(dirname "$ROOT/scripts/test-rust-core-engine-v2.sh")"
cat > "$ROOT/scripts/test-rust-core-engine-v2.sh" <<'FILE_EOF'
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
RUST="$ROOT/rust/maurimesh-core"

echo ""
echo "============================================================"
echo "TEST MAURIMESH RUST CORE ENGINE V2"
echo "============================================================"
echo ""

required=(
  "$RUST/Cargo.toml"
  "$RUST/src/lib.rs"
  "$RUST/src/types.rs"
  "$RUST/src/hash.rs"
  "$RUST/src/packet.rs"
  "$RUST/src/route.rs"
  "$RUST/src/ack.rs"
  "$RUST/src/queue.rs"
  "$RUST/src/proof.rs"
  "$RUST/src/simulation.rs"
  "$RUST/src/truth.rs"
  "$RUST/src/ffi.rs"
  "$RUST/src/main.rs"
  "$ROOT/src/maurimesh/rust-core/types.ts"
  "$ROOT/src/maurimesh/rust-core/RustFallbackEngine.ts"
  "$ROOT/src/maurimesh/rust-core/RustCoreBridge.ts"
  "$ROOT/src/maurimesh/rust-core/MauriMeshRustEnhancementRuntime.ts"
  "$ROOT/src/maurimesh/rust-core/ui/RustCoreStatusPanel.tsx"
  "$ROOT/src/maurimesh/rust-core/index.ts"
  "$ROOT/docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md"
  "$ROOT/docs/RUST_CORE_ENGINE_V2_ARCHITECTURE.md"
)

for file in "${required[@]}"; do
  if [ ! -f "$file" ]; then
    echo "FAIL missing $file"
    exit 1
  fi
  echo "PASS found $file"
done

echo ""
echo "Cargo test if available"
if command -v cargo >/dev/null 2>&1; then
  cd "$RUST"
  cargo test
  cargo run --bin maurimesh-core-cli
else
  echo "WARN cargo not installed here; source and TS bridge checks passed."
fi

echo ""
echo "ALL RUST CORE V2 CHECKS COMPLETED."
FILE_EOF


mkdir -p "$(dirname "$ROOT/docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md")"
cat > "$ROOT/docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md" <<'FILE_EOF'
# Replit Agent Task: Wire MauriMesh Rust Core Engine v2

## Objective

Wire the Rust core as an optional intelligent mesh engine.

Do not replace working React Native, TypeScript, BLE, offline save, proof ledger, security code, or dashboard code.

## Absolute rules

1. Do not depend on `127.0.0.1:4300`.
2. Rust must be optional.
3. TypeScript fallback must keep the app working if Rust/native bridge is unavailable.
4. Simulation proof must not be labelled physical proof.
5. Existing standalone offline save must keep working.
6. Existing BLE paths must not be deleted.

## Enhancement wiring

### 1. Outgoing message / BLE send path

Search:
- `sendMessage`
- `trySendViaBle`
- `TX_BLE_START`
- `writeCharacteristic`
- `sendViaBle`

Before native send:

```ts
import {
  buildMauriMeshPacketWithRustCore,
  scoreMauriMeshRouteWithRustCore,
} from "@/src/maurimesh/rust-core";

const rustPacket = await buildMauriMeshPacketWithRustCore({
  packetId,
  from,
  to,
  payload,
  route,
});

const routeScore = await scoreMauriMeshRouteWithRustCore(rustPacket, {
  batteryPercent,
  trustScore,
  latencyMs,
  duplicateSeen,
});

if (!routeScore.allowed) {
  throw new Error(routeScore.reason);
}
```

### 2. Incoming packet path

Search:
- `RX_BLE`
- `handleIncomingPacket`
- `onPacketReceived`
- `deliver`
- `onCharacteristicWriteRequest`

After packet parse:

```ts
import { rustCoreBridge } from "@/src/maurimesh/rust-core";

const validation = await rustCoreBridge.validatePacket(parsedPacket);

if (!validation.ok) {
  throw new Error(validation.reason);
}
```

### 3. ACK path

Search:
- `ACK`
- `markBleAck`
- `RX_ACK`
- `DELIVERED`

Wire:

```ts
import { validateMauriMeshAckWithRustCore } from "@/src/maurimesh/rust-core";

const ackResult = await validateMauriMeshAckWithRustCore(packetId, {
  ackId,
  from,
  to,
});

if (!ackResult.valid) {
  throw new Error(ackResult.reason);
}
```

### 4. Store-and-forward queue

Search:
- `queue`
- `storeForward`
- `retry`
- `pendingAck`

Wire:

```ts
import { decideMauriMeshQueueWithRustCore } from "@/src/maurimesh/rust-core";

const queueDecision = await decideMauriMeshQueueWithRustCore({
  sendOk,
  ackReceived,
  retryCount,
  maxRetries: 5,
});
```

### 5. Proof ledger

Search:
- `ProofLedger`
- `recordProof`
- `proofLedgerEngine`
- `packet_sent`
- `ack_received`

Wire:

```ts
import { createMauriMeshProofWithRustCore } from "@/src/maurimesh/rust-core";

const proof = await createMauriMeshProofWithRustCore({
  packetId,
  eventType: "PACKET_SENT",
  source: "BLE_RUNTIME",
  verified: false,
  message: "Packet sent; waiting for physical ACK.",
});
```

### 6. Simulation

Search:
- `simulation`
- `sim`
- `mesh tick`
- `runtime truth`

Wire:

```ts
import { runMauriMeshSimulationTickWithRustCore } from "@/src/maurimesh/rust-core";

const tick = await runMauriMeshSimulationTickWithRustCore();
```

### 7. UI

Add to proof/debug/developer dashboard:

```tsx
import RustCoreStatusPanel from "@/src/maurimesh/rust-core/ui/RustCoreStatusPanel";

<RustCoreStatusPanel />
```

## Required tests

Run:

```bash
bash scripts/test-rust-core-engine-v2.sh
```

If cargo exists:

```bash
cd rust/maurimesh-core
cargo test
cargo run --bin maurimesh-core-cli
```

## Completion report required

Report:

1. Exact files changed.
2. Exact send path wired.
3. Exact receive path wired.
4. Exact ACK path wired.
5. Exact proof path wired.
6. Exact queue path wired.
7. Where RustCoreStatusPanel appears.
8. Whether cargo compiled.
9. Whether fallback works.
10. Remaining blockers.

Completion is not accepted if the app fails when Rust is unavailable.
FILE_EOF


chmod +x "$ROOT/scripts/test-rust-core-engine-v2.sh"

echo ""
echo "============================================================"
echo "RUNNING RUST CORE V2 CHECKS"
echo "============================================================"
bash "$ROOT/scripts/test-rust-core-engine-v2.sh"

echo ""
echo "============================================================"
echo "INSTALL COMPLETE"
echo "============================================================"
echo "Created:"
echo "- rust/maurimesh-core"
echo "- src/maurimesh/rust-core"
echo "- src/maurimesh/rust-core/ui/RustCoreStatusPanel.tsx"
echo "- docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md"
echo "- docs/RUST_CORE_ENGINE_V2_ARCHITECTURE.md"
echo "- scripts/test-rust-core-engine-v2.sh"
echo ""
echo "Next: Give Replit Agent docs/RUST_CORE_ENGINE_V2_AGENT_PROMPT.md"
