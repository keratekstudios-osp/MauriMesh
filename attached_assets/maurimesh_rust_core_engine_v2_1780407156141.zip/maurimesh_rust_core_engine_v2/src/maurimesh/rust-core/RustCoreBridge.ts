import type {
  RustAckEvent,
  RustAckValidation,
  RustCoreStatus,
  RustMeshPacket,
  RustProofEvent,
  RustQueueDecision,
  RustRouteInput,
  RustRouteScore,
  RustRuntimeTruthScore,
  RustSimulationNode,
  RustSimulationTick,
} from "./types";
import { rustFallbackEngine } from "./RustFallbackEngine";

export class RustCoreBridge {
  async status(): Promise<RustCoreStatus> {
    return {
      available: true,
      mode: "typescript-fallback",
      version: "maurimesh-core-v2-fallback",
      reason: "Rust core source is installed. TypeScript fallback is active until Kotlin/JSI native Rust bridge is wired.",
    };
  }

  async buildPacket(packet: RustMeshPacket): Promise<RustMeshPacket> {
    return rustFallbackEngine.buildPacket(packet);
  }

  async validatePacket(packet: RustMeshPacket): Promise<{ ok: boolean; reason: string }> {
    return rustFallbackEngine.validatePacket(packet);
  }

  async scoreRoute(input: RustRouteInput): Promise<RustRouteScore> {
    return rustFallbackEngine.scoreRoute(input);
  }

  async validateAck(expectedPacketId: string, ack: RustAckEvent): Promise<RustAckValidation> {
    return rustFallbackEngine.validateAck(expectedPacketId, ack);
  }

  async decideQueue(input: { sendOk: boolean; ackReceived: boolean; retryCount: number; maxRetries: number }): Promise<RustQueueDecision> {
    return rustFallbackEngine.decideQueue(input);
  }

  async createProofEvent(input: Omit<RustProofEvent, "proofId">): Promise<RustProofEvent> {
    return rustFallbackEngine.createProofEvent(input);
  }

  async runSimulationTick(tickId: string, nodes: RustSimulationNode[]): Promise<RustSimulationTick> {
    return rustFallbackEngine.runSimulationTick(tickId, nodes);
  }

  async scoreRuntimeTruth(input: { realNative: boolean; verified: boolean; sourceAuthenticated: boolean; physicalEvidence: boolean }): Promise<RustRuntimeTruthScore> {
    return rustFallbackEngine.scoreRuntimeTruth(input);
  }
}

export const rustCoreBridge = new RustCoreBridge();
