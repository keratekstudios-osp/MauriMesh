import type {
  RustAckEvent,
  RustAckValidation,
  RustMeshPacket,
  RustProofEvent,
  RustQueueDecision,
  RustRouteInput,
  RustRouteScore,
  RustRuntimeTruthScore,
  RustSimulationNode,
  RustSimulationTick,
} from "./types";

function stableHash(input: string): string {
  let hash = BigInt("14695981039346656037");
  const prime = BigInt("1099511628211");
  const mask = BigInt("0xffffffffffffffff");

  for (let i = 0; i < input.length; i += 1) {
    hash ^= BigInt(input.charCodeAt(i));
    hash = (hash * prime) & mask;
  }

  return hash.toString(16).padStart(16, "0");
}

export class RustFallbackEngine {
  buildPacket(packet: RustMeshPacket): RustMeshPacket {
    const payloadHash = stableHash([
      packet.packetId,
      packet.from,
      packet.to,
      String(packet.createdAtMs),
      packet.payload,
      String(packet.ttl),
      String(packet.hopCount),
      packet.route.join(","),
    ].join("|"));

    return { ...packet, payloadHash };
  }

  validatePacket(packet: RustMeshPacket): { ok: boolean; reason: string } {
    if (!packet.packetId) return { ok: false, reason: "packetId is required." };
    if (!packet.from) return { ok: false, reason: "from is required." };
    if (!packet.to) return { ok: false, reason: "to is required." };
    if (packet.ttl <= 0) return { ok: false, reason: "ttl expired." };
    if (packet.hopCount > packet.ttl) return { ok: false, reason: "hopCount exceeds ttl." };
    if (!packet.payloadHash) return { ok: false, reason: "payloadHash is required." };

    const rebuilt = this.buildPacket({ ...packet, payloadHash: undefined });
    if (rebuilt.payloadHash !== packet.payloadHash) return { ok: false, reason: "payloadHash mismatch." };

    return { ok: true, reason: "packet valid." };
  }

  scoreRoute(input: RustRouteInput): RustRouteScore {
    let riskScore = 0;
    const validation = this.validatePacket(input.packet);

    if (!validation.ok) riskScore += 35;
    if (input.packet.ttl <= 0) riskScore += 25;
    if (input.packet.hopCount > input.packet.ttl) riskScore += 25;
    if (input.duplicateSeen) riskScore += 30;
    if (input.batteryPercent < 10) riskScore += 15;
    if (input.trustScore < 45) riskScore += 25;
    if (input.latencyMs > 8000) riskScore += 10;
    if (!input.candidateRoute.includes(input.packet.to) && input.packet.to !== "BROADCAST") riskScore += 10;

    const allowed = riskScore < 45 && !input.duplicateSeen && input.packet.ttl > 0 && input.packet.hopCount <= input.packet.ttl;

    return {
      allowed,
      riskScore,
      routeScore: Math.max(0, 100 - riskScore),
      reason: allowed ? "route allowed by TypeScript Rust fallback" : `route blocked by TypeScript Rust fallback: ${validation.reason}`,
      recommendedRoute: allowed ? input.candidateRoute : [],
      engine: "typescript-fallback",
    };
  }

  validateAck(expectedPacketId: string, ack: RustAckEvent): RustAckValidation {
    if (ack.packetId !== expectedPacketId) return { valid: false, reason: "ACK packetId does not match expected packet.", engine: "typescript-fallback" };
    if (!ack.ackId || !ack.from || !ack.to) return { valid: false, reason: "ACK is incomplete.", engine: "typescript-fallback" };
    return { valid: true, reason: "ACK valid.", engine: "typescript-fallback" };
  }

  decideQueue(input: { sendOk: boolean; ackReceived: boolean; retryCount: number; maxRetries: number }): RustQueueDecision {
    if (input.sendOk && input.ackReceived) {
      return { shouldQueue: false, shouldRetry: false, shouldDrop: false, reason: "packet delivered and ACKed.", engine: "typescript-fallback" };
    }

    if (input.retryCount >= input.maxRetries) {
      return { shouldQueue: false, shouldRetry: false, shouldDrop: true, reason: "max retries reached; drop or manual review required.", engine: "typescript-fallback" };
    }

    return { shouldQueue: true, shouldRetry: true, shouldDrop: false, reason: "packet requires store-and-forward retry.", engine: "typescript-fallback" };
  }

  createProofEvent(input: Omit<RustProofEvent, "proofId">): RustProofEvent {
    const proofId = stableHash([input.packetId, input.eventType, String(input.createdAtMs), input.source, input.message].join("|"));
    return { ...input, proofId };
  }

  runSimulationTick(tickId: string, nodes: RustSimulationNode[]): RustSimulationTick {
    const online = nodes.filter((node) => node.online);
    const relay = online
      .filter((node) => node.batteryPercent >= 20 && node.trustScore >= 60)
      .sort((a, b) => (b.batteryPercent + b.trustScore) - (a.batteryPercent + a.trustScore))[0];

    return {
      tickId,
      nodeCount: nodes.length,
      onlineCount: online.length,
      recommendedRelay: relay?.nodeId,
      message: relay ? `simulation tick complete; recommended relay ${relay.nodeId}` : "simulation tick complete; no safe relay available",
      engine: "typescript-fallback",
    };
  }

  scoreRuntimeTruth(input: { realNative: boolean; verified: boolean; sourceAuthenticated: boolean; physicalEvidence: boolean }): RustRuntimeTruthScore {
    let score = 0;
    if (input.sourceAuthenticated) score += 20;
    if (input.realNative) score += 25;
    if (input.verified) score += 20;
    if (input.physicalEvidence) score += 35;

    return {
      verified: score >= 80,
      score,
      reason: score >= 80 ? "runtime truth accepted" : "runtime truth not strong enough for physical proof",
      engine: "typescript-fallback",
    };
  }
}

export const rustFallbackEngine = new RustFallbackEngine();
