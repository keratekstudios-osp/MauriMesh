import { rustCoreBridge } from "./RustCoreBridge";
import type { RustMeshPacket, RustProofEvent } from "./types";

export async function buildMauriMeshPacketWithRustCore(input: {
  packetId: string;
  from: string;
  to: string;
  payload: string;
  route?: string[];
  ttl?: number;
  hopCount?: number;
}): Promise<RustMeshPacket> {
  return rustCoreBridge.buildPacket({
    packetId: input.packetId,
    from: input.from,
    to: input.to,
    createdAtMs: Date.now(),
    payload: input.payload,
    ttl: input.ttl ?? 8,
    hopCount: input.hopCount ?? 0,
    route: input.route ?? [input.from, input.to],
  });
}

export async function scoreMauriMeshRouteWithRustCore(packet: RustMeshPacket, input: {
  batteryPercent?: number;
  trustScore?: number;
  latencyMs?: number;
  duplicateSeen?: boolean;
} = {}) {
  return rustCoreBridge.scoreRoute({
    packet,
    candidateRoute: packet.route,
    batteryPercent: input.batteryPercent ?? 100,
    trustScore: input.trustScore ?? 75,
    latencyMs: input.latencyMs ?? 0,
    duplicateSeen: input.duplicateSeen ?? false,
  });
}

export async function validateMauriMeshAckWithRustCore(packetId: string, ack: { ackId: string; from: string; to: string }) {
  return rustCoreBridge.validateAck(packetId, {
    packetId,
    ackId: ack.ackId,
    from: ack.from,
    to: ack.to,
    createdAtMs: Date.now(),
  });
}

export async function decideMauriMeshQueueWithRustCore(input: {
  sendOk: boolean;
  ackReceived: boolean;
  retryCount: number;
  maxRetries?: number;
}) {
  return rustCoreBridge.decideQueue({
    sendOk: input.sendOk,
    ackReceived: input.ackReceived,
    retryCount: input.retryCount,
    maxRetries: input.maxRetries ?? 5,
  });
}

export async function createMauriMeshProofWithRustCore(input: {
  packetId: string;
  eventType: string;
  source: string;
  verified: boolean;
  message: string;
}): Promise<RustProofEvent> {
  return rustCoreBridge.createProofEvent({
    packetId: input.packetId,
    eventType: input.eventType,
    createdAtMs: Date.now(),
    source: input.source,
    verified: input.verified,
    message: input.message,
  });
}

export async function runMauriMeshSimulationTickWithRustCore() {
  return rustCoreBridge.runSimulationTick(`tick-${Date.now()}`, [
    { nodeId: "PHONE_A_SIM", label: "Sender", batteryPercent: 88, trustScore: 91, online: true },
    { nodeId: "PHONE_B_SIM", label: "Receiver", batteryPercent: 76, trustScore: 94, online: true },
    { nodeId: "PHONE_C_SIM", label: "Relay", batteryPercent: 92, trustScore: 86, online: true },
  ]);
}
