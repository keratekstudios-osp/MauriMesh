export type RustCoreMode = "native-library" | "rust-cli" | "typescript-fallback" | "unavailable";

export interface RustMeshPacket {
  packetId: string;
  from: string;
  to: string;
  createdAtMs: number;
  payload: string;
  ttl: number;
  hopCount: number;
  route: string[];
  payloadHash?: string;
}

export interface RustRouteInput {
  packet: RustMeshPacket;
  candidateRoute: string[];
  batteryPercent: number;
  trustScore: number;
  latencyMs: number;
  duplicateSeen: boolean;
}

export interface RustRouteScore {
  allowed: boolean;
  riskScore: number;
  routeScore: number;
  reason: string;
  recommendedRoute: string[];
  engine: RustCoreMode;
}

export interface RustAckEvent {
  packetId: string;
  ackId: string;
  from: string;
  to: string;
  createdAtMs: number;
}

export interface RustAckValidation {
  valid: boolean;
  reason: string;
  engine: RustCoreMode;
}

export interface RustQueueDecision {
  shouldQueue: boolean;
  shouldRetry: boolean;
  shouldDrop: boolean;
  reason: string;
  engine: RustCoreMode;
}

export interface RustProofEvent {
  proofId: string;
  packetId: string;
  eventType: string;
  createdAtMs: number;
  source: string;
  verified: boolean;
  message: string;
}

export interface RustSimulationNode {
  nodeId: string;
  label: string;
  batteryPercent: number;
  trustScore: number;
  online: boolean;
}

export interface RustSimulationTick {
  tickId: string;
  nodeCount: number;
  onlineCount: number;
  recommendedRelay?: string;
  message: string;
  engine: RustCoreMode;
}

export interface RustRuntimeTruthScore {
  verified: boolean;
  score: number;
  reason: string;
  engine: RustCoreMode;
}

export interface RustCoreStatus {
  available: boolean;
  mode: RustCoreMode;
  version: string;
  reason: string;
}
