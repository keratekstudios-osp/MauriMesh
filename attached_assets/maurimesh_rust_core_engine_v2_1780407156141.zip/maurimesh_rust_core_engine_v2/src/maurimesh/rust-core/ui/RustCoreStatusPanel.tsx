import React, { useEffect, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import {
  buildMauriMeshPacketWithRustCore,
  createMauriMeshProofWithRustCore,
  decideMauriMeshQueueWithRustCore,
  runMauriMeshSimulationTickWithRustCore,
  rustCoreBridge,
  scoreMauriMeshRouteWithRustCore,
  validateMauriMeshAckWithRustCore,
} from "../index";

const card = {
  backgroundColor: "#0F172A",
  borderRadius: 18,
  borderWidth: 1,
  borderColor: "rgba(0,208,132,0.35)",
  padding: 16,
  marginBottom: 12,
} as const;

const title = { color: "#FFFFFF", fontSize: 20, fontWeight: "800" as const, marginBottom: 8 };
const text = { color: "#CFFAFE", fontSize: 13, lineHeight: 19 };
const button = { backgroundColor: "#00D084", padding: 12, borderRadius: 14, marginTop: 10 };
const buttonText = { color: "#03140D", fontWeight: "800" as const, textAlign: "center" as const };

export default function RustCoreStatusPanel() {
  const [status, setStatus] = useState<any>(null);
  const [result, setResult] = useState<any>(null);

  async function refresh() {
    setStatus(await rustCoreBridge.status());
  }

  async function runFullFlow() {
    const packet = await buildMauriMeshPacketWithRustCore({
      packetId: `MM-RUST-UI-${Date.now()}`,
      from: "PHONE_A",
      to: "PHONE_B",
      payload: "kia ora from MauriMesh Rust Core v2",
    });

    const packetValidation = await rustCoreBridge.validatePacket(packet);
    const route = await scoreMauriMeshRouteWithRustCore(packet, {
      batteryPercent: 88,
      trustScore: 91,
      latencyMs: 40,
      duplicateSeen: false,
    });

    const ack = await validateMauriMeshAckWithRustCore(packet.packetId, {
      ackId: `ACK-${packet.packetId}`,
      from: "PHONE_B",
      to: "PHONE_A",
    });

    const queue = await decideMauriMeshQueueWithRustCore({
      sendOk: route.allowed,
      ackReceived: ack.valid,
      retryCount: 0,
    });

    const proof = await createMauriMeshProofWithRustCore({
      packetId: packet.packetId,
      eventType: "RUST_CORE_SIMULATION",
      source: "RustCoreStatusPanel",
      verified: false,
      message: "Rust core enhanced packet, route, ACK, queue, and proof logic. Simulation only, not physical BLE proof.",
    });

    const simulation = await runMauriMeshSimulationTickWithRustCore();

    const truth = await rustCoreBridge.scoreRuntimeTruth({
      realNative: false,
      verified: true,
      sourceAuthenticated: true,
      physicalEvidence: false,
    });

    setResult({ packet, packetValidation, route, ack, queue, proof, simulation, truth });
  }

  useEffect(() => { refresh(); }, []);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#020617" }} contentContainerStyle={{ padding: 16 }}>
      <View style={card}>
        <Text style={title}>MauriMesh Rust Core v2</Text>
        <Text style={text}>Available: {String(status?.available ?? false)}</Text>
        <Text style={text}>Mode: {status?.mode ?? "unknown"}</Text>
        <Text style={text}>Version: {status?.version ?? "unknown"}</Text>
        <Text style={text}>Reason: {status?.reason ?? "not checked"}</Text>

        <TouchableOpacity style={button} onPress={refresh}>
          <Text style={buttonText}>Refresh Rust Core Status</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={runFullFlow}>
          <Text style={buttonText}>Run Full Rust Core Flow</Text>
        </TouchableOpacity>
      </View>

      {result ? (
        <View style={card}>
          <Text style={title}>Rust Core Result</Text>
          <Text style={text}>{JSON.stringify(result, null, 2)}</Text>
        </View>
      ) : null}
    </ScrollView>
  );
}
