#!/usr/bin/env bash
set -euo pipefail

echo ""
echo "============================================================"
echo "MAURIMESH REAL INTEGRATION SYSTEM INSTALLER"
echo "architecture -> runtime -> UI -> device -> testing -> proof"
echo "============================================================"
echo ""

ROOT="$(pwd)"
BASE="$ROOT/src/maurimesh/real-integration"
UI="$BASE/ui"
TEMPLATES="$BASE/templates"
DOCS="$ROOT/docs"
SCRIPTS="$ROOT/scripts"
BACKUP="$ROOT/backup-before-real-integration-system-$(date +%Y%m%d-%H%M%S)"

mkdir -p "$BASE" "$UI" "$TEMPLATES" "$DOCS" "$SCRIPTS" "$BACKUP"

cat > "$BACKUP/README.txt" <<'TXT'
Backup marker created before installing MauriMesh Real Integration System.
This installer creates new files only.
It does not delete existing BLE, routing, security, native Android, UI, proof, or governance files.
TXT


mkdir -p "$(dirname "$ROOT/docs/REAL_INTEGRATION_LANGUAGE.md")"
cat > "$ROOT/docs/REAL_INTEGRATION_LANGUAGE.md" <<'FILE_EOF'
# MauriMesh Real Integration Language

## Core terms

### Architecture
The permanent shape of the integration: contracts, boundaries, modules, folders, and ownership.

### Runtime
The live execution path where real user/device actions trigger code.

### UI
The user-visible control and status surface.

### Device capability
The native phone capability required to physically perform the action.

### Testing
The repeatable validation of logic, runtime wiring, and device behavior.

### Proof
The durable evidence that something physically happened.

## Real Integration Sentence

Use this format for every integration:

```text
When USER_ACTION happens in UI_COMPONENT, it calls RUNTIME_ACTION, which validates DATA_CONTRACT, checks DEVICE_CAPABILITY, executes NATIVE_ACTION, records PROOF_EVENT, updates STATE_STORE, and renders RESULT_STATE.
```

## Example

```text
When Start Sender is pressed in TwoPhoneProofPanel, it calls startTwoPhoneProofSender, which validates CanonicalPacket, checks BLE_SCAN/BLE_CONNECT/BLE_ADVERTISE, executes native BLE write, records TX_BLE_SENT, updates ProofLedgerStore, and renders Waiting For ACK.
```

## Completion gate

An integration is complete only when all are true:

- The architecture contract exists.
- The runtime function is called by the real path.
- The UI exposes the action and result state.
- The native device capability is checked and available.
- The result is persisted.
- Errors are captured.
- Tests pass.
- Physical proof exists.
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/types.ts")"
cat > "$ROOT/src/maurimesh/real-integration/types.ts" <<'FILE_EOF'
export type IntegrationLayer =
  | "architecture"
  | "runtime"
  | "ui"
  | "device"
  | "testing"
  | "proof";

export type IntegrationStatus =
  | "missing"
  | "scaffolded"
  | "wired"
  | "running"
  | "proved"
  | "blocked"
  | "failed";

export type DeviceCapability =
  | "BLE_SCAN"
  | "BLE_CONNECT"
  | "BLE_ADVERTISE"
  | "BLE_GATT_SERVER"
  | "BLE_GATT_CLIENT"
  | "WIFI_DIRECT"
  | "LOCAL_WIFI"
  | "INTERNET"
  | "STORAGE"
  | "NOTIFICATIONS"
  | "FOREGROUND_SERVICE"
  | "BIOMETRIC_IDENTITY"
  | "SECURE_KEYSTORE"
  | "LOCATION"
  | "UNKNOWN";

export type ProofEventType =
  | "ARCHITECTURE_DEFINED"
  | "RUNTIME_WIRED"
  | "UI_ACTION_TRIGGERED"
  | "DEVICE_CAPABILITY_CHECKED"
  | "NATIVE_ACTION_STARTED"
  | "NATIVE_ACTION_SUCCEEDED"
  | "NATIVE_ACTION_FAILED"
  | "PACKET_HASHED"
  | "PACKET_SENT"
  | "PACKET_RECEIVED"
  | "ACK_SENT"
  | "ACK_RECEIVED"
  | "STATE_PERSISTED"
  | "TEST_PASSED"
  | "TEST_FAILED"
  | "PHYSICAL_PROOF_CONFIRMED";

export interface IntegrationContract {
  id: string;
  name: string;
  purpose: string;
  successCondition: string;
  failureCondition: string;
  owner?: string;
  layers: IntegrationLayer[];
  requiredCapabilities: DeviceCapability[];
  dataContracts: string[];
  runtimeEntryPoints: string[];
  uiEntryPoints: string[];
  proofEvents: ProofEventType[];
}

export interface RuntimeActionInput {
  integrationId: string;
  action: string;
  actor: string;
  deviceId: string;
  payload: unknown;
  createdAt: string;
  metadata?: Record<string, unknown>;
}

export interface RuntimeActionResult {
  integrationId: string;
  action: string;
  status: IntegrationStatus;
  ok: boolean;
  message: string;
  proofId?: string;
  error?: string;
  metadata?: Record<string, unknown>;
}

export interface DeviceCapabilityCheck {
  capability: DeviceCapability;
  available: boolean;
  permissionGranted: boolean;
  nativeModuleAvailable: boolean;
  detail: string;
}

export interface ProofEvent {
  id: string;
  integrationId: string;
  type: ProofEventType;
  createdAt: string;
  actor: string;
  deviceId: string;
  message: string;
  payloadHash?: string;
  metadata?: Record<string, unknown>;
}

export interface IntegrationTestCase {
  id: string;
  name: string;
  layer: IntegrationLayer;
  run: () => Promise<boolean> | boolean;
}

export interface IntegrationTestResult {
  id: string;
  name: string;
  layer: IntegrationLayer;
  passed: boolean;
  detail: string;
}

export interface IntegrationReadinessReport {
  integrationId: string;
  generatedAt: string;
  score: number;
  status: IntegrationStatus;
  layers: Record<IntegrationLayer, boolean>;
  capabilities: DeviceCapabilityCheck[];
  blockers: string[];
  warnings: string[];
  tests: IntegrationTestResult[];
  proofEvents: ProofEvent[];
}
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/IntegrationContractEngine.ts")"
cat > "$ROOT/src/maurimesh/real-integration/IntegrationContractEngine.ts" <<'FILE_EOF'
import type { DeviceCapability, IntegrationContract, IntegrationLayer, ProofEventType } from "./types";

export class IntegrationContractEngine {
  define(input: {
    id: string;
    name: string;
    purpose: string;
    successCondition: string;
    failureCondition: string;
    owner?: string;
    requiredCapabilities?: DeviceCapability[];
    dataContracts?: string[];
    runtimeEntryPoints?: string[];
    uiEntryPoints?: string[];
    proofEvents?: ProofEventType[];
  }): IntegrationContract {
    const layers: IntegrationLayer[] = [
      "architecture",
      "runtime",
      "ui",
      "device",
      "testing",
      "proof",
    ];

    return {
      id: input.id,
      name: input.name,
      purpose: input.purpose,
      successCondition: input.successCondition,
      failureCondition: input.failureCondition,
      owner: input.owner,
      layers,
      requiredCapabilities: input.requiredCapabilities ?? [],
      dataContracts: input.dataContracts ?? [],
      runtimeEntryPoints: input.runtimeEntryPoints ?? [],
      uiEntryPoints: input.uiEntryPoints ?? [],
      proofEvents: input.proofEvents ?? [],
    };
  }

  validate(contract: IntegrationContract): { ok: boolean; blockers: string[] } {
    const blockers: string[] = [];

    if (!contract.id.trim()) blockers.push("Missing integration id.");
    if (!contract.name.trim()) blockers.push("Missing integration name.");
    if (!contract.purpose.trim()) blockers.push("Missing purpose.");
    if (!contract.successCondition.trim()) blockers.push("Missing success condition.");
    if (!contract.failureCondition.trim()) blockers.push("Missing failure condition.");
    if (contract.requiredCapabilities.length === 0) blockers.push("No device capability declared.");
    if (contract.dataContracts.length === 0) blockers.push("No data contract declared.");
    if (contract.runtimeEntryPoints.length === 0) blockers.push("No runtime entry point declared.");
    if (contract.uiEntryPoints.length === 0) blockers.push("No UI entry point declared.");
    if (contract.proofEvents.length === 0) blockers.push("No proof events declared.");

    return {
      ok: blockers.length === 0,
      blockers,
    };
  }
}

export const integrationContractEngine = new IntegrationContractEngine();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/hash.ts")"
cat > "$ROOT/src/maurimesh/real-integration/hash.ts" <<'FILE_EOF'
export function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  const objectValue = value as Record<string, unknown>;
  return `{${Object.keys(objectValue)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableStringify(objectValue[key])}`)
    .join(",")}}`;
}

export function djb2Hash(input: string): string {
  let hash = 5381;
  for (let i = 0; i < input.length; i += 1) {
    hash = ((hash << 5) + hash + input.charCodeAt(i)) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

export function proofHash(value: unknown): string {
  return djb2Hash(stableStringify(value));
}
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/ProofEventLedger.ts")"
cat > "$ROOT/src/maurimesh/real-integration/ProofEventLedger.ts" <<'FILE_EOF'
import type { ProofEvent, ProofEventType } from "./types";
import { proofHash } from "./hash";

function makeId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export class ProofEventLedger {
  private events: ProofEvent[] = [];

  record(input: {
    integrationId: string;
    type: ProofEventType;
    actor: string;
    deviceId: string;
    message: string;
    payload?: unknown;
    metadata?: Record<string, unknown>;
  }): ProofEvent {
    const event: ProofEvent = {
      id: makeId("proof-event"),
      integrationId: input.integrationId,
      type: input.type,
      createdAt: new Date().toISOString(),
      actor: input.actor,
      deviceId: input.deviceId,
      message: input.message,
      payloadHash: input.payload === undefined ? undefined : proofHash(input.payload),
      metadata: input.metadata,
    };

    this.events.unshift(event);
    return event;
  }

  list(integrationId?: string, limit = 100): ProofEvent[] {
    const source = integrationId
      ? this.events.filter((event) => event.integrationId === integrationId)
      : this.events;

    return source.slice(0, limit);
  }

  has(integrationId: string, type: ProofEvent["type"]): boolean {
    return this.events.some((event) => event.integrationId === integrationId && event.type === type);
  }

  clear(): void {
    this.events = [];
  }
}

export const proofEventLedger = new ProofEventLedger();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/DeviceCapabilityEngine.ts")"
cat > "$ROOT/src/maurimesh/real-integration/DeviceCapabilityEngine.ts" <<'FILE_EOF'
import type { DeviceCapability, DeviceCapabilityCheck } from "./types";

export class DeviceCapabilityEngine {
  async check(capability: DeviceCapability): Promise<DeviceCapabilityCheck> {
    // Default JS-safe check. Real app must replace or enrich this with native checks.
    const known = capability !== "UNKNOWN";

    return {
      capability,
      available: known,
      permissionGranted: known,
      nativeModuleAvailable: known,
      detail: known
        ? `${capability} declared. Replace this default with the real native/device check.`
        : "Unknown capability.",
    };
  }

  async checkMany(capabilities: DeviceCapability[]): Promise<DeviceCapabilityCheck[]> {
    const results: DeviceCapabilityCheck[] = [];
    for (const capability of capabilities) {
      results.push(await this.check(capability));
    }
    return results;
  }
}

export const deviceCapabilityEngine = new DeviceCapabilityEngine();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/RuntimeWorkflowEngine.ts")"
cat > "$ROOT/src/maurimesh/real-integration/RuntimeWorkflowEngine.ts" <<'FILE_EOF'
import type { IntegrationContract, RuntimeActionInput, RuntimeActionResult } from "./types";
import { deviceCapabilityEngine } from "./DeviceCapabilityEngine";
import { proofEventLedger } from "./ProofEventLedger";

export class RuntimeWorkflowEngine {
  async run(
    contract: IntegrationContract,
    input: RuntimeActionInput,
    executeNativeAction?: (input: RuntimeActionInput) => Promise<boolean>
  ): Promise<RuntimeActionResult> {
    try {
      proofEventLedger.record({
        integrationId: contract.id,
        type: "UI_ACTION_TRIGGERED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `UI triggered action ${input.action}.`,
        payload: input.payload,
      });

      const checks = await deviceCapabilityEngine.checkMany(contract.requiredCapabilities);
      proofEventLedger.record({
        integrationId: contract.id,
        type: "DEVICE_CAPABILITY_CHECKED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `Checked ${checks.length} capabilities.`,
        payload: checks,
      });

      const missing = checks.filter(
        (check) => !check.available || !check.permissionGranted || !check.nativeModuleAvailable
      );

      if (missing.length > 0) {
        return {
          integrationId: contract.id,
          action: input.action,
          status: "blocked",
          ok: false,
          message: "Device capability gate blocked runtime action.",
          error: missing.map((item) => `${item.capability}: ${item.detail}`).join("; "),
          metadata: { checks },
        };
      }

      proofEventLedger.record({
        integrationId: contract.id,
        type: "NATIVE_ACTION_STARTED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `Native action started for ${input.action}.`,
        payload: input.payload,
      });

      const nativeOk = executeNativeAction ? await executeNativeAction(input) : true;

      proofEventLedger.record({
        integrationId: contract.id,
        type: nativeOk ? "NATIVE_ACTION_SUCCEEDED" : "NATIVE_ACTION_FAILED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: nativeOk
          ? `Native action succeeded for ${input.action}.`
          : `Native action failed for ${input.action}.`,
        payload: input.payload,
      });

      if (!nativeOk) {
        return {
          integrationId: contract.id,
          action: input.action,
          status: "failed",
          ok: false,
          message: "Runtime action executed but native layer failed.",
          metadata: { checks },
        };
      }

      return {
        integrationId: contract.id,
        action: input.action,
        status: "running",
        ok: true,
        message: "Runtime action executed.",
        metadata: { checks },
      };
    } catch (error) {
      return {
        integrationId: contract.id,
        action: input.action,
        status: "failed",
        ok: false,
        message: "Runtime workflow crashed.",
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }
}

export const runtimeWorkflowEngine = new RuntimeWorkflowEngine();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/IntegrationReadinessGate.ts")"
cat > "$ROOT/src/maurimesh/real-integration/IntegrationReadinessGate.ts" <<'FILE_EOF'
import type { IntegrationContract, IntegrationReadinessReport, IntegrationTestResult } from "./types";
import { integrationContractEngine } from "./IntegrationContractEngine";
import { deviceCapabilityEngine } from "./DeviceCapabilityEngine";
import { proofEventLedger } from "./ProofEventLedger";

export class IntegrationReadinessGate {
  async evaluate(contract: IntegrationContract, tests: IntegrationTestResult[] = []): Promise<IntegrationReadinessReport> {
    const validation = integrationContractEngine.validate(contract);
    const capabilities = await deviceCapabilityEngine.checkMany(contract.requiredCapabilities);

    const layers = {
      architecture: validation.ok,
      runtime: contract.runtimeEntryPoints.length > 0,
      ui: contract.uiEntryPoints.length > 0,
      device: capabilities.every((check) => check.available && check.permissionGranted && check.nativeModuleAvailable),
      testing: tests.length > 0 && tests.every((test) => test.passed),
      proof: contract.proofEvents.every((type) => proofEventLedger.has(contract.id, type)),
    };

    const blockers: string[] = [...validation.blockers];
    const warnings: string[] = [];

    for (const capability of capabilities) {
      if (!capability.available) blockers.push(`${capability.capability} not available.`);
      if (!capability.permissionGranted) blockers.push(`${capability.capability} permission not granted.`);
      if (!capability.nativeModuleAvailable) blockers.push(`${capability.capability} native module not available.`);
    }

    if (tests.length === 0) blockers.push("No tests supplied.");
    if (tests.some((test) => !test.passed)) blockers.push("One or more tests failed.");

    const missingProof = contract.proofEvents.filter((type) => !proofEventLedger.has(contract.id, type));
    for (const type of missingProof) warnings.push(`Missing proof event: ${type}`);

    const layerValues = Object.values(layers);
    const score = Math.round((layerValues.filter(Boolean).length / layerValues.length) * 100);

    return {
      integrationId: contract.id,
      generatedAt: new Date().toISOString(),
      score,
      status: blockers.length > 0 ? "blocked" : score === 100 ? "proved" : "wired",
      layers,
      capabilities,
      blockers,
      warnings,
      tests,
      proofEvents: proofEventLedger.list(contract.id, 100),
    };
  }
}

export const integrationReadinessGate = new IntegrationReadinessGate();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/IntegrationTestEngine.ts")"
cat > "$ROOT/src/maurimesh/real-integration/IntegrationTestEngine.ts" <<'FILE_EOF'
import type { IntegrationTestCase, IntegrationTestResult } from "./types";

export class IntegrationTestEngine {
  async run(tests: IntegrationTestCase[]): Promise<IntegrationTestResult[]> {
    const results: IntegrationTestResult[] = [];

    for (const test of tests) {
      try {
        const passed = await test.run();
        results.push({
          id: test.id,
          name: test.name,
          layer: test.layer,
          passed,
          detail: passed ? "Passed." : "Returned false.",
        });
      } catch (error) {
        results.push({
          id: test.id,
          name: test.name,
          layer: test.layer,
          passed: false,
          detail: error instanceof Error ? error.message : String(error),
        });
      }
    }

    return results;
  }
}

export const integrationTestEngine = new IntegrationTestEngine();
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/templates/twoPhoneBleProofContract.ts")"
cat > "$ROOT/src/maurimesh/real-integration/templates/twoPhoneBleProofContract.ts" <<'FILE_EOF'
import { integrationContractEngine } from "../IntegrationContractEngine";

export const twoPhoneBleProofContract = integrationContractEngine.define({
  id: "two-phone-ble-proof",
  name: "Two Phone BLE Proof",
  purpose: "Physically prove that PHONE_A can send a BLE packet to PHONE_B and receive a real ACK.",
  successCondition: "PHONE_A sends packet, PHONE_B receives, PHONE_B sends ACK, PHONE_A records ACK, ledger stores proof.",
  failureCondition: "Missing permission, peer not found, send failure, receive failure, ACK timeout, bad hash, or native module unavailable.",
  owner: "MauriMesh",
  requiredCapabilities: [
    "BLE_SCAN",
    "BLE_CONNECT",
    "BLE_ADVERTISE",
    "BLE_GATT_CLIENT",
    "BLE_GATT_SERVER",
    "STORAGE",
    "FOREGROUND_SERVICE",
  ],
  dataContracts: [
    "CanonicalPacket",
    "HashedPacket",
    "ProofEvent",
    "TwoPhoneProofSession",
  ],
  runtimeEntryPoints: [
    "startTwoPhoneProofSender",
    "startTwoPhoneProofReceiver",
    "trySendViaBle",
    "handleIncomingPacket",
    "markBleAck",
  ],
  uiEntryPoints: [
    "TwoPhoneProofPanel",
    "Start PHONE_A Sender",
    "Start PHONE_B Receiver",
    "Send Proof Packet",
    "View Proof Ledger",
  ],
  proofEvents: [
    "UI_ACTION_TRIGGERED",
    "DEVICE_CAPABILITY_CHECKED",
    "NATIVE_ACTION_STARTED",
    "NATIVE_ACTION_SUCCEEDED",
    "PACKET_SENT",
    "PACKET_RECEIVED",
    "ACK_RECEIVED",
    "STATE_PERSISTED",
    "PHYSICAL_PROOF_CONFIRMED",
  ],
});
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/ui/RealIntegrationPanel.tsx")"
cat > "$ROOT/src/maurimesh/real-integration/ui/RealIntegrationPanel.tsx" <<'FILE_EOF'
import React, { useMemo, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { runtimeWorkflowEngine } from "../RuntimeWorkflowEngine";
import { integrationReadinessGate } from "../IntegrationReadinessGate";
import { integrationTestEngine } from "../IntegrationTestEngine";
import { proofEventLedger } from "../ProofEventLedger";
import { twoPhoneBleProofContract } from "../templates/twoPhoneBleProofContract";

const card = {
  backgroundColor: "#0F172A",
  borderColor: "rgba(0,208,132,0.35)",
  borderWidth: 1,
  borderRadius: 18,
  padding: 16,
  marginBottom: 12,
} as const;

const title = {
  color: "#FFFFFF",
  fontSize: 20,
  fontWeight: "800" as const,
  marginBottom: 8,
};

const text = {
  color: "#CFFAFE",
  fontSize: 13,
  lineHeight: 19,
};

const button = {
  backgroundColor: "#00D084",
  borderRadius: 14,
  paddingVertical: 12,
  paddingHorizontal: 14,
  marginTop: 10,
};

const buttonText = {
  color: "#03140D",
  fontWeight: "800" as const,
  textAlign: "center" as const,
};

export default function RealIntegrationPanel() {
  const [log, setLog] = useState<string[]>([]);
  const [report, setReport] = useState<any>(null);

  const contract = useMemo(() => twoPhoneBleProofContract, []);

  async function runWorkflow() {
    const result = await runtimeWorkflowEngine.run(
      contract,
      {
        integrationId: contract.id,
        action: "START_TWO_PHONE_BLE_PROOF",
        actor: "local-user",
        deviceId: "local-device",
        createdAt: new Date().toISOString(),
        payload: {
          packetId: `MM-PROOF-${Date.now()}`,
          from: "PHONE_A",
          to: "PHONE_B",
          transport: "BLE",
        },
      },
      async () => true
    );

    setLog((current) => [`${result.status}: ${result.message}`, ...current]);
  }

  async function confirmPhysicalProof() {
    proofEventLedger.record({
      integrationId: contract.id,
      type: "PACKET_SENT",
      actor: "PHONE_A",
      deviceId: "PHONE_A",
      message: "Physical proof placeholder: packet sent event recorded. Wire this to real TX_BLE_SENT.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "PACKET_RECEIVED",
      actor: "PHONE_B",
      deviceId: "PHONE_B",
      message: "Physical proof placeholder: packet received event recorded. Wire this to real RX_BLE_RECEIVED.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "ACK_RECEIVED",
      actor: "PHONE_A",
      deviceId: "PHONE_A",
      message: "Physical proof placeholder: ACK received event recorded. Wire this to real ACK_RECEIVED.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "STATE_PERSISTED",
      actor: "local-runtime",
      deviceId: "local-device",
      message: "State persisted event recorded. Wire this to SQLite/MMKV persistence confirmation.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "PHYSICAL_PROOF_CONFIRMED",
      actor: "operator",
      deviceId: "two-phone-test",
      message: "Operator confirmed physical two-phone proof. Replace with ADB/log evidence in production.",
    });

    setLog((current) => ["Proof events recorded.", ...current]);
  }

  async function runGate() {
    const tests = await integrationTestEngine.run([
      {
        id: "contract-has-name",
        name: "Contract has name",
        layer: "architecture",
        run: () => Boolean(contract.name),
      },
      {
        id: "contract-has-runtime",
        name: "Contract has runtime entry points",
        layer: "runtime",
        run: () => contract.runtimeEntryPoints.length > 0,
      },
      {
        id: "contract-has-ui",
        name: "Contract has UI entry points",
        layer: "ui",
        run: () => contract.uiEntryPoints.length > 0,
      },
    ]);

    const nextReport = await integrationReadinessGate.evaluate(contract, tests);
    setReport(nextReport);
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#020617" }} contentContainerStyle={{ padding: 16 }}>
      <View style={card}>
        <Text style={title}>Real Integration Panel</Text>
        <Text style={text}>Integration: {contract.name}</Text>
        <Text style={text}>Purpose: {contract.purpose}</Text>

        <TouchableOpacity style={button} onPress={runWorkflow}>
          <Text style={buttonText}>Run Runtime Workflow</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={confirmPhysicalProof}>
          <Text style={buttonText}>Record Physical Proof Events</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={runGate}>
          <Text style={buttonText}>Run Readiness Gate</Text>
        </TouchableOpacity>
      </View>

      <View style={card}>
        <Text style={title}>Log</Text>
        {log.map((line, index) => (
          <Text key={`${line}-${index}`} style={text}>{line}</Text>
        ))}
      </View>

      {report ? (
        <View style={card}>
          <Text style={title}>Readiness Report</Text>
          <Text style={text}>{JSON.stringify(report, null, 2)}</Text>
        </View>
      ) : null}
    </ScrollView>
  );
}
FILE_EOF

mkdir -p "$(dirname "$ROOT/src/maurimesh/real-integration/index.ts")"
cat > "$ROOT/src/maurimesh/real-integration/index.ts" <<'FILE_EOF'
export * from "./types";
export * from "./hash";
export * from "./IntegrationContractEngine";
export * from "./ProofEventLedger";
export * from "./DeviceCapabilityEngine";
export * from "./RuntimeWorkflowEngine";
export * from "./IntegrationTestEngine";
export * from "./IntegrationReadinessGate";
export * from "./templates/twoPhoneBleProofContract";
FILE_EOF

mkdir -p "$(dirname "$ROOT/docs/REAL_INTEGRATION_AGENT_PROMPT.md")"
cat > "$ROOT/docs/REAL_INTEGRATION_AGENT_PROMPT.md" <<'FILE_EOF'
# Replit Agent Prompt: Create Real Physical Integrations

## Objective

Wire the MauriMesh real-integration system into the existing app so each integration follows:

architecture -> runtime -> UI -> device capability -> testing -> proof

Do not delete existing BLE, routing, native Android, security, proof, dashboard, or governance work.

## Installed source

- `src/maurimesh/real-integration/types.ts`
- `src/maurimesh/real-integration/IntegrationContractEngine.ts`
- `src/maurimesh/real-integration/RuntimeWorkflowEngine.ts`
- `src/maurimesh/real-integration/DeviceCapabilityEngine.ts`
- `src/maurimesh/real-integration/ProofEventLedger.ts`
- `src/maurimesh/real-integration/IntegrationTestEngine.ts`
- `src/maurimesh/real-integration/IntegrationReadinessGate.ts`
- `src/maurimesh/real-integration/templates/twoPhoneBleProofContract.ts`
- `src/maurimesh/real-integration/ui/RealIntegrationPanel.tsx`

## Mandatory wiring

### 1. Architecture

Every integration must define an `IntegrationContract`.

Required fields:

- id
- name
- purpose
- successCondition
- failureCondition
- requiredCapabilities
- dataContracts
- runtimeEntryPoints
- uiEntryPoints
- proofEvents

### 2. Runtime

Find the real runtime path.

For BLE, search:

- `TX_BLE_START`
- `RX_BLE`
- `ACK`
- `sendViaBle`
- `writeCharacteristic`
- `onCharacteristicWriteRequest`
- `BlePlxCompat`
- `native BLE`

When the UI starts a feature, call `runtimeWorkflowEngine.run(...)`.

### 3. UI

Add `RealIntegrationPanel` to the developer/proof/debug dashboard without breaking navigation.

Import:

    import RealIntegrationPanel from "@/src/maurimesh/real-integration/ui/RealIntegrationPanel";

Render:

    <RealIntegrationPanel />

### 4. Device capability

Replace default placeholder capability checks inside `DeviceCapabilityEngine` with real app checks where available.

For Android BLE, verify:

- AndroidManifest permission exists
- runtime permission is granted
- native module exists
- Bluetooth is on
- scanner is available
- advertiser is available
- GATT server/client path is callable

### 5. Testing

Add tests for:

- contract validity
- UI action calls runtime
- runtime calls native capability gate
- failed capability blocks action
- proof event records
- physical proof events are not created from fake success
- two-phone proof only passes after ACK

### 6. Proof

Wire proof events to real runtime events:

- `PACKET_SENT` from real TX_BLE_SENT
- `PACKET_RECEIVED` from real RX_BLE_RECEIVED
- `ACK_SENT` from real ACK transmit
- `ACK_RECEIVED` from real ACK receive
- `STATE_PERSISTED` from actual persistent store write
- `PHYSICAL_PROOF_CONFIRMED` only after two-phone ADB/log proof

## Completion rule

Do not mark complete unless:

- UI action triggers runtime.
- Runtime checks device capability.
- Native action performs real work.
- Runtime records proof events.
- State is persisted.
- Tests pass.
- Two physical Android devices can repeat the proof.
- APK build still works.
FILE_EOF

mkdir -p "$(dirname "$ROOT/scripts/test-real-integration-kit.mjs")"
cat > "$ROOT/scripts/test-real-integration-kit.mjs" <<'FILE_EOF'
import fs from "fs";
import path from "path";

const root = process.cwd();
const base = path.join(root, "src", "maurimesh", "real-integration");

const required = [
  "types.ts",
  "hash.ts",
  "IntegrationContractEngine.ts",
  "ProofEventLedger.ts",
  "DeviceCapabilityEngine.ts",
  "RuntimeWorkflowEngine.ts",
  "IntegrationTestEngine.ts",
  "IntegrationReadinessGate.ts",
  "templates/twoPhoneBleProofContract.ts",
  "ui/RealIntegrationPanel.tsx",
  "index.ts",
];

let failed = 0;

for (const file of required) {
  const full = path.join(base, file);
  if (!fs.existsSync(full)) {
    console.log(`FAIL missing ${file}`);
    failed += 1;
  } else {
    console.log(`PASS found ${file}`);
  }
}

const prompt = path.join(root, "docs", "REAL_INTEGRATION_AGENT_PROMPT.md");
if (!fs.existsSync(prompt)) {
  console.log("FAIL missing docs/REAL_INTEGRATION_AGENT_PROMPT.md");
  failed += 1;
} else {
  console.log("PASS found docs/REAL_INTEGRATION_AGENT_PROMPT.md");
}

if (failed > 0) {
  console.log(`FAILED: ${failed} issue(s).`);
  process.exit(1);
}

console.log("ALL REAL INTEGRATION KIT FILE CHECKS PASSED.");
FILE_EOF

chmod +x "$SCRIPTS/test-real-integration-kit.mjs" 2>/dev/null || true

echo ""
echo "============================================================"
echo "RUNNING REAL INTEGRATION FILE CHECKS"
echo "============================================================"
node "$SCRIPTS/test-real-integration-kit.mjs"

echo ""
echo "============================================================"
echo "INSTALL COMPLETE"
echo "============================================================"
echo "Created:"
echo "- src/maurimesh/real-integration"
echo "- src/maurimesh/real-integration/ui/RealIntegrationPanel.tsx"
echo "- docs/REAL_INTEGRATION_AGENT_PROMPT.md"
echo "- docs/REAL_INTEGRATION_LANGUAGE.md"
echo "- scripts/test-real-integration-kit.mjs"
echo ""
echo "Next:"
echo "Give Replit Agent: Open docs/REAL_INTEGRATION_AGENT_PROMPT.md and wire this into the real BLE/UI/proof paths."
echo ""
