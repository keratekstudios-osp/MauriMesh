import fs from "fs";
import path from "path";

const root = process.cwd();
const base = path.join(root, "src", "maurimesh", "real-integration");

const required = [
  "types.ts",
  "hash.ts",
  "IntegrationContractEngine.ts",
  "ProofEventLedger.ts",
  "DeviceCapabilityEngine.ts",
  "RuntimeWorkflowEngine.ts",
  "IntegrationTestEngine.ts",
  "IntegrationReadinessGate.ts",
  "templates/twoPhoneBleProofContract.ts",
  "ui/RealIntegrationPanel.tsx",
  "index.ts",
];

let failed = 0;

for (const file of required) {
  const full = path.join(base, file);
  if (!fs.existsSync(full)) {
    console.log(`FAIL missing ${file}`);
    failed += 1;
  } else {
    console.log(`PASS found ${file}`);
  }
}

const prompt = path.join(root, "docs", "REAL_INTEGRATION_AGENT_PROMPT.md");
if (!fs.existsSync(prompt)) {
  console.log("FAIL missing docs/REAL_INTEGRATION_AGENT_PROMPT.md");
  failed += 1;
} else {
  console.log("PASS found docs/REAL_INTEGRATION_AGENT_PROMPT.md");
}

if (failed > 0) {
  console.log(`FAILED: ${failed} issue(s).`);
  process.exit(1);
}

console.log("ALL REAL INTEGRATION KIT FILE CHECKS PASSED.");
