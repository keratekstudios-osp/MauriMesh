# Replit Agent Prompt: Create Real Physical Integrations

## Objective

Wire the MauriMesh real-integration system into the existing app so each integration follows:

architecture -> runtime -> UI -> device capability -> testing -> proof

Do not delete existing BLE, routing, native Android, security, proof, dashboard, or governance work.

## Installed source

- `src/maurimesh/real-integration/types.ts`
- `src/maurimesh/real-integration/IntegrationContractEngine.ts`
- `src/maurimesh/real-integration/RuntimeWorkflowEngine.ts`
- `src/maurimesh/real-integration/DeviceCapabilityEngine.ts`
- `src/maurimesh/real-integration/ProofEventLedger.ts`
- `src/maurimesh/real-integration/IntegrationTestEngine.ts`
- `src/maurimesh/real-integration/IntegrationReadinessGate.ts`
- `src/maurimesh/real-integration/templates/twoPhoneBleProofContract.ts`
- `src/maurimesh/real-integration/ui/RealIntegrationPanel.tsx`

## Mandatory wiring

### 1. Architecture

Every integration must define an `IntegrationContract`.

Required fields:

- id
- name
- purpose
- successCondition
- failureCondition
- requiredCapabilities
- dataContracts
- runtimeEntryPoints
- uiEntryPoints
- proofEvents

### 2. Runtime

Find the real runtime path.

For BLE, search:

- `TX_BLE_START`
- `RX_BLE`
- `ACK`
- `sendViaBle`
- `writeCharacteristic`
- `onCharacteristicWriteRequest`
- `BlePlxCompat`
- `native BLE`

When the UI starts a feature, call `runtimeWorkflowEngine.run(...)`.

### 3. UI

Add `RealIntegrationPanel` to the developer/proof/debug dashboard without breaking navigation.

Import:

    import RealIntegrationPanel from "@/src/maurimesh/real-integration/ui/RealIntegrationPanel";

Render:

    <RealIntegrationPanel />

### 4. Device capability

Replace default placeholder capability checks inside `DeviceCapabilityEngine` with real app checks where available.

For Android BLE, verify:

- AndroidManifest permission exists
- runtime permission is granted
- native module exists
- Bluetooth is on
- scanner is available
- advertiser is available
- GATT server/client path is callable

### 5. Testing

Add tests for:

- contract validity
- UI action calls runtime
- runtime calls native capability gate
- failed capability blocks action
- proof event records
- physical proof events are not created from fake success
- two-phone proof only passes after ACK

### 6. Proof

Wire proof events to real runtime events:

- `PACKET_SENT` from real TX_BLE_SENT
- `PACKET_RECEIVED` from real RX_BLE_RECEIVED
- `ACK_SENT` from real ACK transmit
- `ACK_RECEIVED` from real ACK receive
- `STATE_PERSISTED` from actual persistent store write
- `PHYSICAL_PROOF_CONFIRMED` only after two-phone ADB/log proof

## Completion rule

Do not mark complete unless:

- UI action triggers runtime.
- Runtime checks device capability.
- Native action performs real work.
- Runtime records proof events.
- State is persisted.
- Tests pass.
- Two physical Android devices can repeat the proof.
- APK build still works.
