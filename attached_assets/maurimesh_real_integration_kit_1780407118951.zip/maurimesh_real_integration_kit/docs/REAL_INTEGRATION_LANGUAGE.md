# MauriMesh Real Integration Language

## Core terms

### Architecture
The permanent shape of the integration: contracts, boundaries, modules, folders, and ownership.

### Runtime
The live execution path where real user/device actions trigger code.

### UI
The user-visible control and status surface.

### Device capability
The native phone capability required to physically perform the action.

### Testing
The repeatable validation of logic, runtime wiring, and device behavior.

### Proof
The durable evidence that something physically happened.

## Real Integration Sentence

Use this format for every integration:

```text
When USER_ACTION happens in UI_COMPONENT, it calls RUNTIME_ACTION, which validates DATA_CONTRACT, checks DEVICE_CAPABILITY, executes NATIVE_ACTION, records PROOF_EVENT, updates STATE_STORE, and renders RESULT_STATE.
```

## Example

```text
When Start Sender is pressed in TwoPhoneProofPanel, it calls startTwoPhoneProofSender, which validates CanonicalPacket, checks BLE_SCAN/BLE_CONNECT/BLE_ADVERTISE, executes native BLE write, records TX_BLE_SENT, updates ProofLedgerStore, and renders Waiting For ACK.
```

## Completion gate

An integration is complete only when all are true:

- The architecture contract exists.
- The runtime function is called by the real path.
- The UI exposes the action and result state.
- The native device capability is checked and available.
- The result is persisted.
- Errors are captured.
- Tests pass.
- Physical proof exists.
