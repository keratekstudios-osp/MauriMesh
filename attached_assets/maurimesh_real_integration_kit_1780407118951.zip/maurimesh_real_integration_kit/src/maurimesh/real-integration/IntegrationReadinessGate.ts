import type { IntegrationContract, IntegrationReadinessReport, IntegrationTestResult } from "./types";
import { integrationContractEngine } from "./IntegrationContractEngine";
import { deviceCapabilityEngine } from "./DeviceCapabilityEngine";
import { proofEventLedger } from "./ProofEventLedger";

export class IntegrationReadinessGate {
  async evaluate(contract: IntegrationContract, tests: IntegrationTestResult[] = []): Promise<IntegrationReadinessReport> {
    const validation = integrationContractEngine.validate(contract);
    const capabilities = await deviceCapabilityEngine.checkMany(contract.requiredCapabilities);

    const layers = {
      architecture: validation.ok,
      runtime: contract.runtimeEntryPoints.length > 0,
      ui: contract.uiEntryPoints.length > 0,
      device: capabilities.every((check) => check.available && check.permissionGranted && check.nativeModuleAvailable),
      testing: tests.length > 0 && tests.every((test) => test.passed),
      proof: contract.proofEvents.every((type) => proofEventLedger.has(contract.id, type)),
    };

    const blockers: string[] = [...validation.blockers];
    const warnings: string[] = [];

    for (const capability of capabilities) {
      if (!capability.available) blockers.push(`${capability.capability} not available.`);
      if (!capability.permissionGranted) blockers.push(`${capability.capability} permission not granted.`);
      if (!capability.nativeModuleAvailable) blockers.push(`${capability.capability} native module not available.`);
    }

    if (tests.length === 0) blockers.push("No tests supplied.");
    if (tests.some((test) => !test.passed)) blockers.push("One or more tests failed.");

    const missingProof = contract.proofEvents.filter((type) => !proofEventLedger.has(contract.id, type));
    for (const type of missingProof) warnings.push(`Missing proof event: ${type}`);

    const layerValues = Object.values(layers);
    const score = Math.round((layerValues.filter(Boolean).length / layerValues.length) * 100);

    return {
      integrationId: contract.id,
      generatedAt: new Date().toISOString(),
      score,
      status: blockers.length > 0 ? "blocked" : score === 100 ? "proved" : "wired",
      layers,
      capabilities,
      blockers,
      warnings,
      tests,
      proofEvents: proofEventLedger.list(contract.id, 100),
    };
  }
}

export const integrationReadinessGate = new IntegrationReadinessGate();
