import type { IntegrationTestCase, IntegrationTestResult } from "./types";

export class IntegrationTestEngine {
  async run(tests: IntegrationTestCase[]): Promise<IntegrationTestResult[]> {
    const results: IntegrationTestResult[] = [];

    for (const test of tests) {
      try {
        const passed = await test.run();
        results.push({
          id: test.id,
          name: test.name,
          layer: test.layer,
          passed,
          detail: passed ? "Passed." : "Returned false.",
        });
      } catch (error) {
        results.push({
          id: test.id,
          name: test.name,
          layer: test.layer,
          passed: false,
          detail: error instanceof Error ? error.message : String(error),
        });
      }
    }

    return results;
  }
}

export const integrationTestEngine = new IntegrationTestEngine();
