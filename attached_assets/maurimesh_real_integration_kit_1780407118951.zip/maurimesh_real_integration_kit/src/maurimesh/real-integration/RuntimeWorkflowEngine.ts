import type { IntegrationContract, RuntimeActionInput, RuntimeActionResult } from "./types";
import { deviceCapabilityEngine } from "./DeviceCapabilityEngine";
import { proofEventLedger } from "./ProofEventLedger";

export class RuntimeWorkflowEngine {
  async run(
    contract: IntegrationContract,
    input: RuntimeActionInput,
    executeNativeAction?: (input: RuntimeActionInput) => Promise<boolean>
  ): Promise<RuntimeActionResult> {
    try {
      proofEventLedger.record({
        integrationId: contract.id,
        type: "UI_ACTION_TRIGGERED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `UI triggered action ${input.action}.`,
        payload: input.payload,
      });

      const checks = await deviceCapabilityEngine.checkMany(contract.requiredCapabilities);
      proofEventLedger.record({
        integrationId: contract.id,
        type: "DEVICE_CAPABILITY_CHECKED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `Checked ${checks.length} capabilities.`,
        payload: checks,
      });

      const missing = checks.filter(
        (check) => !check.available || !check.permissionGranted || !check.nativeModuleAvailable
      );

      if (missing.length > 0) {
        return {
          integrationId: contract.id,
          action: input.action,
          status: "blocked",
          ok: false,
          message: "Device capability gate blocked runtime action.",
          error: missing.map((item) => `${item.capability}: ${item.detail}`).join("; "),
          metadata: { checks },
        };
      }

      proofEventLedger.record({
        integrationId: contract.id,
        type: "NATIVE_ACTION_STARTED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: `Native action started for ${input.action}.`,
        payload: input.payload,
      });

      const nativeOk = executeNativeAction ? await executeNativeAction(input) : true;

      proofEventLedger.record({
        integrationId: contract.id,
        type: nativeOk ? "NATIVE_ACTION_SUCCEEDED" : "NATIVE_ACTION_FAILED",
        actor: input.actor,
        deviceId: input.deviceId,
        message: nativeOk
          ? `Native action succeeded for ${input.action}.`
          : `Native action failed for ${input.action}.`,
        payload: input.payload,
      });

      if (!nativeOk) {
        return {
          integrationId: contract.id,
          action: input.action,
          status: "failed",
          ok: false,
          message: "Runtime action executed but native layer failed.",
          metadata: { checks },
        };
      }

      return {
        integrationId: contract.id,
        action: input.action,
        status: "running",
        ok: true,
        message: "Runtime action executed.",
        metadata: { checks },
      };
    } catch (error) {
      return {
        integrationId: contract.id,
        action: input.action,
        status: "failed",
        ok: false,
        message: "Runtime workflow crashed.",
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }
}

export const runtimeWorkflowEngine = new RuntimeWorkflowEngine();
