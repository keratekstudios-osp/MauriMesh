import type { DeviceCapability, DeviceCapabilityCheck } from "./types";

export class DeviceCapabilityEngine {
  async check(capability: DeviceCapability): Promise<DeviceCapabilityCheck> {
    // Default JS-safe check. Real app must replace or enrich this with native checks.
    const known = capability !== "UNKNOWN";

    return {
      capability,
      available: known,
      permissionGranted: known,
      nativeModuleAvailable: known,
      detail: known
        ? `${capability} declared. Replace this default with the real native/device check.`
        : "Unknown capability.",
    };
  }

  async checkMany(capabilities: DeviceCapability[]): Promise<DeviceCapabilityCheck[]> {
    const results: DeviceCapabilityCheck[] = [];
    for (const capability of capabilities) {
      results.push(await this.check(capability));
    }
    return results;
  }
}

export const deviceCapabilityEngine = new DeviceCapabilityEngine();
