import type { ProofEvent, ProofEventType } from "./types";
import { proofHash } from "./hash";

function makeId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export class ProofEventLedger {
  private events: ProofEvent[] = [];

  record(input: {
    integrationId: string;
    type: ProofEventType;
    actor: string;
    deviceId: string;
    message: string;
    payload?: unknown;
    metadata?: Record<string, unknown>;
  }): ProofEvent {
    const event: ProofEvent = {
      id: makeId("proof-event"),
      integrationId: input.integrationId,
      type: input.type,
      createdAt: new Date().toISOString(),
      actor: input.actor,
      deviceId: input.deviceId,
      message: input.message,
      payloadHash: input.payload === undefined ? undefined : proofHash(input.payload),
      metadata: input.metadata,
    };

    this.events.unshift(event);
    return event;
  }

  list(integrationId?: string, limit = 100): ProofEvent[] {
    const source = integrationId
      ? this.events.filter((event) => event.integrationId === integrationId)
      : this.events;

    return source.slice(0, limit);
  }

  has(integrationId: string, type: ProofEvent["type"]): boolean {
    return this.events.some((event) => event.integrationId === integrationId && event.type === type);
  }

  clear(): void {
    this.events = [];
  }
}

export const proofEventLedger = new ProofEventLedger();
