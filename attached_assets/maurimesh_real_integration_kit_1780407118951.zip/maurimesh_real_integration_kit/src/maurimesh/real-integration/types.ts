export type IntegrationLayer =
  | "architecture"
  | "runtime"
  | "ui"
  | "device"
  | "testing"
  | "proof";

export type IntegrationStatus =
  | "missing"
  | "scaffolded"
  | "wired"
  | "running"
  | "proved"
  | "blocked"
  | "failed";

export type DeviceCapability =
  | "BLE_SCAN"
  | "BLE_CONNECT"
  | "BLE_ADVERTISE"
  | "BLE_GATT_SERVER"
  | "BLE_GATT_CLIENT"
  | "WIFI_DIRECT"
  | "LOCAL_WIFI"
  | "INTERNET"
  | "STORAGE"
  | "NOTIFICATIONS"
  | "FOREGROUND_SERVICE"
  | "BIOMETRIC_IDENTITY"
  | "SECURE_KEYSTORE"
  | "LOCATION"
  | "UNKNOWN";

export type ProofEventType =
  | "ARCHITECTURE_DEFINED"
  | "RUNTIME_WIRED"
  | "UI_ACTION_TRIGGERED"
  | "DEVICE_CAPABILITY_CHECKED"
  | "NATIVE_ACTION_STARTED"
  | "NATIVE_ACTION_SUCCEEDED"
  | "NATIVE_ACTION_FAILED"
  | "PACKET_HASHED"
  | "PACKET_SENT"
  | "PACKET_RECEIVED"
  | "ACK_SENT"
  | "ACK_RECEIVED"
  | "STATE_PERSISTED"
  | "TEST_PASSED"
  | "TEST_FAILED"
  | "PHYSICAL_PROOF_CONFIRMED";

export interface IntegrationContract {
  id: string;
  name: string;
  purpose: string;
  successCondition: string;
  failureCondition: string;
  owner?: string;
  layers: IntegrationLayer[];
  requiredCapabilities: DeviceCapability[];
  dataContracts: string[];
  runtimeEntryPoints: string[];
  uiEntryPoints: string[];
  proofEvents: ProofEventType[];
}

export interface RuntimeActionInput {
  integrationId: string;
  action: string;
  actor: string;
  deviceId: string;
  payload: unknown;
  createdAt: string;
  metadata?: Record<string, unknown>;
}

export interface RuntimeActionResult {
  integrationId: string;
  action: string;
  status: IntegrationStatus;
  ok: boolean;
  message: string;
  proofId?: string;
  error?: string;
  metadata?: Record<string, unknown>;
}

export interface DeviceCapabilityCheck {
  capability: DeviceCapability;
  available: boolean;
  permissionGranted: boolean;
  nativeModuleAvailable: boolean;
  detail: string;
}

export interface ProofEvent {
  id: string;
  integrationId: string;
  type: ProofEventType;
  createdAt: string;
  actor: string;
  deviceId: string;
  message: string;
  payloadHash?: string;
  metadata?: Record<string, unknown>;
}

export interface IntegrationTestCase {
  id: string;
  name: string;
  layer: IntegrationLayer;
  run: () => Promise<boolean> | boolean;
}

export interface IntegrationTestResult {
  id: string;
  name: string;
  layer: IntegrationLayer;
  passed: boolean;
  detail: string;
}

export interface IntegrationReadinessReport {
  integrationId: string;
  generatedAt: string;
  score: number;
  status: IntegrationStatus;
  layers: Record<IntegrationLayer, boolean>;
  capabilities: DeviceCapabilityCheck[];
  blockers: string[];
  warnings: string[];
  tests: IntegrationTestResult[];
  proofEvents: ProofEvent[];
}
