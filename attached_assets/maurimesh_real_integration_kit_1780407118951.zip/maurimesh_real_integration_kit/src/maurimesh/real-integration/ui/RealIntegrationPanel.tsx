import React, { useMemo, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { runtimeWorkflowEngine } from "../RuntimeWorkflowEngine";
import { integrationReadinessGate } from "../IntegrationReadinessGate";
import { integrationTestEngine } from "../IntegrationTestEngine";
import { proofEventLedger } from "../ProofEventLedger";
import { twoPhoneBleProofContract } from "../templates/twoPhoneBleProofContract";

const card = {
  backgroundColor: "#0F172A",
  borderColor: "rgba(0,208,132,0.35)",
  borderWidth: 1,
  borderRadius: 18,
  padding: 16,
  marginBottom: 12,
} as const;

const title = {
  color: "#FFFFFF",
  fontSize: 20,
  fontWeight: "800" as const,
  marginBottom: 8,
};

const text = {
  color: "#CFFAFE",
  fontSize: 13,
  lineHeight: 19,
};

const button = {
  backgroundColor: "#00D084",
  borderRadius: 14,
  paddingVertical: 12,
  paddingHorizontal: 14,
  marginTop: 10,
};

const buttonText = {
  color: "#03140D",
  fontWeight: "800" as const,
  textAlign: "center" as const,
};

export default function RealIntegrationPanel() {
  const [log, setLog] = useState<string[]>([]);
  const [report, setReport] = useState<any>(null);

  const contract = useMemo(() => twoPhoneBleProofContract, []);

  async function runWorkflow() {
    const result = await runtimeWorkflowEngine.run(
      contract,
      {
        integrationId: contract.id,
        action: "START_TWO_PHONE_BLE_PROOF",
        actor: "local-user",
        deviceId: "local-device",
        createdAt: new Date().toISOString(),
        payload: {
          packetId: `MM-PROOF-${Date.now()}`,
          from: "PHONE_A",
          to: "PHONE_B",
          transport: "BLE",
        },
      },
      async () => true
    );

    setLog((current) => [`${result.status}: ${result.message}`, ...current]);
  }

  async function confirmPhysicalProof() {
    proofEventLedger.record({
      integrationId: contract.id,
      type: "PACKET_SENT",
      actor: "PHONE_A",
      deviceId: "PHONE_A",
      message: "Physical proof placeholder: packet sent event recorded. Wire this to real TX_BLE_SENT.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "PACKET_RECEIVED",
      actor: "PHONE_B",
      deviceId: "PHONE_B",
      message: "Physical proof placeholder: packet received event recorded. Wire this to real RX_BLE_RECEIVED.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "ACK_RECEIVED",
      actor: "PHONE_A",
      deviceId: "PHONE_A",
      message: "Physical proof placeholder: ACK received event recorded. Wire this to real ACK_RECEIVED.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "STATE_PERSISTED",
      actor: "local-runtime",
      deviceId: "local-device",
      message: "State persisted event recorded. Wire this to SQLite/MMKV persistence confirmation.",
    });

    proofEventLedger.record({
      integrationId: contract.id,
      type: "PHYSICAL_PROOF_CONFIRMED",
      actor: "operator",
      deviceId: "two-phone-test",
      message: "Operator confirmed physical two-phone proof. Replace with ADB/log evidence in production.",
    });

    setLog((current) => ["Proof events recorded.", ...current]);
  }

  async function runGate() {
    const tests = await integrationTestEngine.run([
      {
        id: "contract-has-name",
        name: "Contract has name",
        layer: "architecture",
        run: () => Boolean(contract.name),
      },
      {
        id: "contract-has-runtime",
        name: "Contract has runtime entry points",
        layer: "runtime",
        run: () => contract.runtimeEntryPoints.length > 0,
      },
      {
        id: "contract-has-ui",
        name: "Contract has UI entry points",
        layer: "ui",
        run: () => contract.uiEntryPoints.length > 0,
      },
    ]);

    const nextReport = await integrationReadinessGate.evaluate(contract, tests);
    setReport(nextReport);
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#020617" }} contentContainerStyle={{ padding: 16 }}>
      <View style={card}>
        <Text style={title}>Real Integration Panel</Text>
        <Text style={text}>Integration: {contract.name}</Text>
        <Text style={text}>Purpose: {contract.purpose}</Text>

        <TouchableOpacity style={button} onPress={runWorkflow}>
          <Text style={buttonText}>Run Runtime Workflow</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={confirmPhysicalProof}>
          <Text style={buttonText}>Record Physical Proof Events</Text>
        </TouchableOpacity>

        <TouchableOpacity style={button} onPress={runGate}>
          <Text style={buttonText}>Run Readiness Gate</Text>
        </TouchableOpacity>
      </View>

      <View style={card}>
        <Text style={title}>Log</Text>
        {log.map((line, index) => (
          <Text key={`${line}-${index}`} style={text}>{line}</Text>
        ))}
      </View>

      {report ? (
        <View style={card}>
          <Text style={title}>Readiness Report</Text>
          <Text style={text}>{JSON.stringify(report, null, 2)}</Text>
        </View>
      ) : null}
    </ScrollView>
  );
}
