import type { DeviceCapability, IntegrationContract, IntegrationLayer, ProofEventType } from "./types";

export class IntegrationContractEngine {
  define(input: {
    id: string;
    name: string;
    purpose: string;
    successCondition: string;
    failureCondition: string;
    owner?: string;
    requiredCapabilities?: DeviceCapability[];
    dataContracts?: string[];
    runtimeEntryPoints?: string[];
    uiEntryPoints?: string[];
    proofEvents?: ProofEventType[];
  }): IntegrationContract {
    const layers: IntegrationLayer[] = [
      "architecture",
      "runtime",
      "ui",
      "device",
      "testing",
      "proof",
    ];

    return {
      id: input.id,
      name: input.name,
      purpose: input.purpose,
      successCondition: input.successCondition,
      failureCondition: input.failureCondition,
      owner: input.owner,
      layers,
      requiredCapabilities: input.requiredCapabilities ?? [],
      dataContracts: input.dataContracts ?? [],
      runtimeEntryPoints: input.runtimeEntryPoints ?? [],
      uiEntryPoints: input.uiEntryPoints ?? [],
      proofEvents: input.proofEvents ?? [],
    };
  }

  validate(contract: IntegrationContract): { ok: boolean; blockers: string[] } {
    const blockers: string[] = [];

    if (!contract.id.trim()) blockers.push("Missing integration id.");
    if (!contract.name.trim()) blockers.push("Missing integration name.");
    if (!contract.purpose.trim()) blockers.push("Missing purpose.");
    if (!contract.successCondition.trim()) blockers.push("Missing success condition.");
    if (!contract.failureCondition.trim()) blockers.push("Missing failure condition.");
    if (contract.requiredCapabilities.length === 0) blockers.push("No device capability declared.");
    if (contract.dataContracts.length === 0) blockers.push("No data contract declared.");
    if (contract.runtimeEntryPoints.length === 0) blockers.push("No runtime entry point declared.");
    if (contract.uiEntryPoints.length === 0) blockers.push("No UI entry point declared.");
    if (contract.proofEvents.length === 0) blockers.push("No proof events declared.");

    return {
      ok: blockers.length === 0,
      blockers,
    };
  }
}

export const integrationContractEngine = new IntegrationContractEngine();
