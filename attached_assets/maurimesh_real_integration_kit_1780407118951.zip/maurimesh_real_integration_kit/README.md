# MauriMesh Real Integration Kit

This kit defines the complete code language and implementation scaffold for turning an app integration into a real physical app capability.

Chain covered:

1. Architecture
2. Runtime
3. UI
4. Device capability
5. Testing
6. Proof

This is designed for MauriMesh but can be reused for any feature. The rule is simple:

A feature is not real because files exist. It is real when UI triggers it, runtime executes it, native device capability performs it, state is persisted, logs prove it, and a physical device test repeats it.

## Install in Replit

Copy `install-maurimesh-real-integration-system.sh` into Replit Shell and run it at the project root.

```bash
bash install-maurimesh-real-integration-system.sh
```

Then give Replit Agent:

```text
Open docs/REAL_INTEGRATION_AGENT_PROMPT.md and wire this system into the real app paths. Completion requires real BLE send, receive, ACK, UI, persistence, logs, and two-phone proof.
```
