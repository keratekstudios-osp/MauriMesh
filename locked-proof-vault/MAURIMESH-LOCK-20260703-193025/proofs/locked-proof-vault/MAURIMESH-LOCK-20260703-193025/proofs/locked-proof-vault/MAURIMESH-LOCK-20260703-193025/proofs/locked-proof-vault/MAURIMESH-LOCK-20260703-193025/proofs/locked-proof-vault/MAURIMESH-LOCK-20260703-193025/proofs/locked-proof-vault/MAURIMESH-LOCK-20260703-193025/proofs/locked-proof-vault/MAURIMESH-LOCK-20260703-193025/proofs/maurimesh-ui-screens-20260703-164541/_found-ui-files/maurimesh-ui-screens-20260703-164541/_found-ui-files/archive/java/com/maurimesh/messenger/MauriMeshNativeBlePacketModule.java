package com.maurimesh.messenger;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;

public class MauriMeshNativeBlePacketModule extends ReactContextBaseJavaModule {
private static final String TAG = "MauriMeshNativeBlePacket";

public MauriMeshNativeBlePacketModule(ReactApplicationContext reactContext) {
super(reactContext);
}

@NonNull
@Override
public String getName() {
return "MauriMeshNativeBlePacket";
}

private String safe(@Nullable String value) {
if (value == null || value.trim().isEmpty()) return "UNKNOWN";
return value.replace("|", "/").replaceAll("\s+", "_");
}

@ReactMethod
public void logPacketEvent(ReadableMap event, Promise promise) {
try {
String role = event.hasKey("role") ? event.getString("role") : "UNKNOWN_ROLE";
String stage = event.hasKey("stage") ? event.getString("stage") : "UNKNOWN_STAGE";
String packetId = event.hasKey("packetId") ? event.getString("packetId") : "NO_PACKET_ID";
String transport = event.hasKey("transport") ? event.getString("transport") : "BRIDGE_LOG_ONLY";
String detail = event.hasKey("detail") ? event.getString("detail") : "NO_DETAIL";

  String line =
    "MAURIMESH_NATIVE_BLE_PACKET"
      + " | role=" + safe(role)
      + " | stage=" + safe(stage)
      + " | packetId=" + safe(packetId)
      + " | transport=" + safe(transport)
      + " | detail=" + safe(detail);

  Log.i(TAG, line);
  promise.resolve(true);
} catch (Exception err) {
  Log.e(TAG, "MAURIMESH_NATIVE_BLE_PACKET | role=UNKNOWN | stage=BLE_ERROR | packetId=NO_PACKET_ID | transport=BRIDGE_LOG_ONLY | detail=" + safe(err.getMessage()));
  promise.reject("MAURIMESH_NATIVE_BLE_PACKET_LOG_ERROR", err);
}

}
}
