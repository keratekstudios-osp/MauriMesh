import { AiPixelReconstructionPanel } from "../src/components/AiPixelReconstructionPanel";
import { PixelCallingBackupFallbackPanel } from "../src/components/PixelCallingBackupFallbackPanel";
import { PixelCallingRuntimePanel } from "../src/components/PixelCallingRuntimePanel";
import { MessageFallbackPanel } from "../src/components/MessageFallbackPanel";
import { HybridWifiBleMeshPanel } from "../src/components/HybridWifiBleMeshPanel";
import React from "react";
import { StyleSheet, Text } from "react-native";
import { AppShell } from "../src/components/AppShell";
import { DeviceProofCard } from "../src/components/DeviceProofCard";
import { mauriTheme } from "../src/theme/mauriTheme";
import { MaoriProtocolPanel } from "../src/components/MaoriProtocolPanel";

export default function DeviceProofScreen() {
  return (
    <AppShell>
      <Text style={styles.title}>Device Proof</Text>
      <Text style={styles.subtitle}>
        APK/device checklist for real BLE, native Bluetooth, QR camera, logcat, packet delivery, and ACK proof.
      </Text>
      <DeviceProofCard />
          <HybridWifiBleMeshPanel />
          <MessageFallbackPanel />
          <PixelCallingRuntimePanel />
          <PixelCallingBackupFallbackPanel />
          <AiPixelReconstructionPanel />
    </AppShell>
  );
}

const styles = StyleSheet.create({
  title: {
    color: mauriTheme.colors.white,
    fontSize: 34,
    fontWeight: "900",
  },
  subtitle: {
    color: mauriTheme.colors.mutedWhite,
    lineHeight: 22,
  },
});

// Māori Protocol restored for Device Proof
